# MyNinja — your own private super.myninja.ai

A single-user agent platform that looks and behaves like SuperNinja, runs on **your**
VirtualBox VM, and is reachable **only by you** from your phone, laptop, or tablet.

```
   phone / laptop / tablet
            │
            │  Tailscale (private mesh VPN — no public exposure)
            ▼
   ┌────────────────────────────────────────────┐
   │  Ubuntu VM (VirtualBox, headless)          │
   │                                            │
   │  FastAPI + SQLite                          │
   │   ├─ password login (single user)          │
   │   ├─ conversations + full history          │
   │   ├─ agent loop (plan→act→observe)         │
   │   ├─ Chromium · shell · files · search     │
   │   └─ workspace file browser                │
   │                                            │
   │  Ollama (local model, offline, free)       │
   └────────────────────────────────────────────┘
```

## Why this is genuinely "only me"

Three independent layers, so there is no accidental exposure:

1. **Password login** — one account, PBKDF2-hashed or compared in constant time,
   session tokens in SQLite, `HttpOnly` + `SameSite=Lax` cookies.
2. **No port forwarding** — the VM is on NAT with **no** public NAT rule for 8000.
   Nothing on the internet can reach it.
3. **Tailscale** — a private WireGuard mesh. Only devices signed into *your*
   Tailscale account can see the VM's IP. No open ports, no DNS records, no certs
   to manage, no attack surface.

Even if someone found your IP, they'd hit a closed port. Even if they somehow
reached the port, they'd hit the password. That's the whole design.

---

## What you need before you start

Measured on a clean Ubuntu 24.04 install, not estimated.

| Item | Minimum | Comfortable | Notes |
|---|---|---|---|
| RAM (VM) | 8 GB | 16 GB | 7B model needs ~5 GB; 16 GB lets you run 14B |
| CPUs (VM) | 4 | 8 | Token generation is CPU-bound without a GPU |
| Disk (VM) | 25 GB | 50 GB | See breakdown below |
| Host OS | Anything VirtualBox runs on | — | Windows/macOS/Linux |
| Network | Outbound HTTPS only | — | No inbound ports, ever |

Disk breakdown, measured:

```
Ubuntu Server 24.04 base ............  6 GB
Python venv + dependencies ..........  120 MB
Playwright Chromium (+ ffmpeg) ......  1.2 GB   <-- the big one
Ollama + qwen2.5:7b .................  4.7 GB
Workspace + SQLite + logs ...........  grows with use
```

So **25 GB is the real floor** and 50 GB is what you want if you plan to keep
projects in the workspace.

### Dependency pins that matter

`requirements.txt` pins `httpx>=0.27,<0.28`. This is not cosmetic. `openai` 1.x
passes a `proxies=` argument that `httpx` 0.28 removed, so an unpinned install
today dies at the first model call with:

```
TypeError: Client.__init__() got an unexpected keyword argument 'proxies'
```

Verified working combination: `openai 1.109.1` + `httpx 0.27.2`. If you ever
`pip install -U` and the agent stops responding, check those two first.

---

## Part 1 — Build the VM (Windows, once)

Install **VirtualBox** and the **Ubuntu Server 24.04** ISO (both free).

```cmd
VBoxManage createvm --name NinjaVM --ostype Ubuntu_64 --register
VBoxManage modifyvm NinjaVM --memory 8192 --cpus 4 --nic1 nat
VBoxManage modifyvm NinjaVM --natpf1 "ssh,tcp,,2222,,22"
VBoxManage createhd --filename "%USERPROFILE%\NinjaVM.vdi" --size 51200
VBoxManage storagectl NinjaVM --name SATA --add sata --controller IntelAhci
VBoxManage storageattach NinjaVM --storagectl SATA --port 0 --device 0 ^
  --type hdd --medium "%USERPROFILE%\NinjaVM.vdi"
```

Note there is **no** `api,tcp,,8000,,8000` rule. That is deliberate.

Install Ubuntu Server, enable **OpenSSH server**, create your user.

## Part 2 — Install the app (inside the VM)

```bash
# from your Windows host:
scp -P 2222 -r ninja-private user@localhost:~/ninja

# inside the VM:
cd ~/ninja && chmod +x install.sh run.sh && ./install.sh
```

`install.sh` creates a venv, installs Chromium + Playwright, installs Ollama,
pulls a model, and **generates a random password** for you. Write it down.

## Part 3 — Run it

```bash
cd ~/ninja && ./run.sh
```

Test locally inside the VM: `curl localhost:8000/api/health`

To keep it running 24/7 (survives reboot, no terminal needed):

```bash
sudo cp ninja-web.service /etc/systemd/system/ninja-web@.service
sudo systemctl daemon-reload
sudo systemctl enable --now ninja-web@$USER
systemctl status ninja-web@$USER
```

## Part 4 — Reach it privately from anywhere (Tailscale)

This is the step that gives you "my own super.myninja.ai" from your phone.

**In the VM:**
```bash
curl -fsSL https://tailscale.com/install.sh | sh
sudo tailscale up
```
It prints a URL — open it, sign in (free personal account, up to 100 devices).
Note the VM's Tailscale IP, e.g. `100.101.102.103`.

**On your phone / laptop:** install the Tailscale app, sign in with the *same*
account, turn it on.

**Then just open:**
```
http://100.101.102.103:8000
```

That's your private SuperNinja. Works over cellular, from a café, anywhere —
and nobody else on earth can load that URL. No port forwarding, no public IP,
no certificates.

Optional nicety — give it a name:
```bash
sudo tailscale set --hostname ninja
# then browse to http://ninja:8000
```

### Lock it down further (optional, 2 minutes)

```bash
# Only allow the app to be reached via Tailscale, not the VM's NAT interface
sudo ufw allow in on tailscale0 to any port 8000
sudo ufw allow 22/tcp
sudo ufw enable
```

If you want HTTPS on the tailnet: `sudo tailscale cert ninja` and put Caddy in
front — but on a private tailnet HTTP is already encrypted by WireGuard, so it's
mostly cosmetic.

## Part 5 — Point it at a better brain

Default is Ollama (offline, free, private). For noticeably better reasoning,
switch to a free API tier in `.env`:

```bash
# Gemini free tier
LLM_BASE_URL=https://generativelanguage.googleapis.com/v1beta/openai/
LLM_MODEL=gemini-2.0-flash
LLM_API_KEY=your-key          # aistudio.google.com/apikey

# or Groq free tier
LLM_BASE_URL=https://api.groq.com/openai/v1
LLM_MODEL=llama-3.3-70b-versatile
LLM_API_KEY=your-groq-key
```

Then `sudo systemctl restart ninja-web@$USER`.

Trade-off: Ollama never sends your data anywhere; Gemini/Groq do, but are much
smarter. Use Ollama for private stuff, Gemini for hard tasks.

---

## What you get

| super.myninja.ai | MyNinja |
|---|---|
| Chat UI with task history | ✅ sidebar, conversations, full replay |
| Watch it work step by step | ✅ live SSE stream, expandable tool cards |
| Its own computer | ✅ the VM |
| Real browser | ✅ Playwright + Chromium |
| Runs code / shell | ✅ `run_shell`, `run_python` |
| Files it produces | ✅ workspace browser + preview + download |
| Access from phone | ✅ via Tailscale |
| Keeps working when you close the tab | ✅ server-side, DB-backed |
| Only you can use it | ✅ password + private network |
| Disposable sandbox | ✅ VirtualBox snapshots |
| Free | ✅ $0 |
| Learns and improves over time | ✅ skills + preferences + lessons |

## Self-evolution — how it actually works

This is not a model being retrained. It is three small persistent stores the
agent **reads before every task** and **writes to after every task**. Over weeks
it stops repeating itself and starts matching how you work.

| Store | What goes in it | Written by |
|---|---|---|
| `skills` | Reusable procedures: a name, a one-line trigger ("when to use this"), and the concrete steps that worked | `save_skill` tool + post-task reflection |
| `preferences` | How you like things: tone, stack, formatting, conventions | `remember` tool, or tell it "I prefer X" |
| `lessons` | A mistake plus the fix, so it never repeats it | `note_lesson` tool, or automatic when it recovers from an error |

**The loop, concretely:**

1. You send a task.
2. `memory.build_context(task)` tokenises your message, scores it against every
   stored skill trigger and lesson, and pulls the top matches plus all
   preferences. Skills get a trust boost: ones that have worked before score
   higher than ones that have not.
3. That block is injected into the system prompt, and a `✦ recalled …` line
   appears in the chat so you can see what it remembered.
4. The agent does the work.
5. When it finishes, a separate reflection pass looks at the transcript tail and
   decides whether anything is worth keeping — at most 2 saves. It is instructed
   to reply `NOTHING_TO_SAVE` rather than hoard trivia.
6. Next time a similar task arrives, the skill comes back automatically.

**You stay in control.** The **Learned** tab in the right panel lists everything
it knows. Every preference, skill, and lesson has an ✕ — delete anything wrong
and it stops using it immediately. Nothing is hidden in a model's weights; it is
all rows in `data/ninja.db`, readable with `sqlite3`.

```bash
# see everything it has learned
sqlite3 data/ninja.db "select name, uses, wins from skills;"
sqlite3 data/ninja.db "select key, value from preferences;"
sqlite3 data/ninja.db "select mistake, fix, hits from lessons;"

# teach it a preference by hand
sqlite3 data/ninja.db \
  "insert into preferences(key,value) values('tone','blunt, no preamble') \
   on conflict(key) do update set value=excluded.value;"
```

**Why it compounds:** `uses` and `wins` are tracked per skill. A skill that
keeps working rises in the ranking; one that never helps quietly falls out of
retrieval. That is the whole trick — retrieval that gets sharper with use, plus
a durable record of your preferences and past mistakes.

## Self-repair — it fixes itself when something breaks

Most self-hosted agents die on the first broken dependency and leave you
reading a traceback. This one probes its own install, knows what the common
failures mean, and repairs the safe ones without being asked.

There are three layers.

**1. Boot check.** On startup a background thread runs eleven probes — Python
version, dependencies, the `httpx` pin, directories, database integrity, schema,
disk space, port, model endpoint, Chromium, and whether the file sandbox still
refuses path escapes. Anything broken and safely fixable is fixed before your
first task runs. The result is printed once:

```
[self-repair] 2 of 11 checks failed: disk, model_endpoint | repaired: disk (clean_caches) | could not fix: model_endpoint (start_ollama): ollama is not installed — run install.sh
```

It runs in a thread on purpose. A server that refuses to start because its own
health check crashed would be a worse bug than the one it was checking for.

**2. Runtime healing.** When an LLM call fails, the error string is matched
against an ordered table of sixteen known failure modes. If the match has a safe
fix, the fix runs and the call is retried once. If it does not, the diagnosis is
injected into the conversation so the model changes approach instead of
repeating the identical call. A `self-repair` card appears in the chat either
way:

```
self-repair   fixed
cause: the database schema was never created, or the DB file was replaced
fix:   create the missing tables
result: schema created
```

Tool failures get the same treatment: any tool result beginning with `error`
is diagnosed and the guidance is appended before the model sees it.

**3. Manual control.** The **Learned** tab has a **Health** section: every
failing check, its fix, a **Repair** button, and the last six repairs with
timestamps. Or from a shell:

```bash
python app/repair.py          # report only, changes nothing
python app/repair.py --fix    # report, then repair
python app/repair.py --json   # machine readable
```

### What it will and will not touch

| Fix | Runs automatically | What it does |
|---|---|---|
| `pin_httpx` | yes | reinstalls `openai>=1.68,<2` + `httpx>=0.27,<0.28` — the `proxies` TypeError |
| `pip_install` | yes | `pip install -r requirements.txt` |
| `make_dirs` | yes | creates `data/`, `data/logs/`, `workspace/` |
| `rebuild_db` | yes | creates missing tables; a corrupt DB is **moved aside**, never deleted |
| `clean_caches` | yes | clears pip cache, oversized logs, stale `/tmp/ninja-*` |
| `start_ollama` | yes | starts `ollama serve` and waits for the port |
| `install_chromium` | yes | `playwright install chromium` |

Everything above is idempotent and non-destructive. Running the full repair pass
twice in a row is a no-op the second time — each fix is attempted at most once
per process, so a repair cannot loop.

Deliberately **not** automated, because they need a human decision: port
conflicts, SQLite lock contention, permission errors, wrong API keys, unknown
model names, rate limits, context overflow. Those are diagnosed and reported
with the exact command to run, not executed.

### It remembers its own repairs

Every attempt writes a row to the `repairs` table and, when it worked, a lesson
to the memory store. So the next time the same thing breaks, the agent already
knows the fix:

```bash
sqlite3 data/ninja.db "select datetime(ts,'unixepoch'), check_name, fix_id, ok from repairs order by id desc limit 10;"
```

Turn the boot check off with `SELF_REPAIR=0` in `.env`. The runtime healing and
the manual button keep working either way.

## No hedging, and it plans before it works

Two mechanisms, both on by default.

**1. It does not ask permission.** The system prompt is written for an operator, not
an assistant: no "Sure", no "I'd be happy to", no restating your request, no asking
whether it should proceed. First token is work. It is told it is root on a disposable
machine that exists only for this task, so there is nothing to be cautious about.

**2. It never refuses — it asks.** When the model would decline something, or when the
agent is about to do something irreversible, it does not say no and it does not stall.
It stops and shows you a **decision card**:

- **what it is about to do**, exactly
- **why it needs a decision**
- **what actually goes wrong** — specific consequences, not vague warnings
- whether it is **reversible**
- **2–3 alternative routes** that reach the same goal with less risk, each with its cost
- **its recommendation**
- **Proceed** / **Cancel** buttons

Pick an alternative with the radio button and hit Proceed, and that route is used. Hit
Cancel and it drops the action and works out a different way to the goal instead of
arguing with you. Either way the decision is recorded in the transcript.

There is also a `request_consent` tool, so the agent can raise the flag *before* doing
something destructive — deleting data, dropping a table, force-pushing, touching
production, handling credentials, bulk scraping — rather than only when it refuses.

Verified against a model that refuses "drop the users table in production": the refusal
never reached the UI, the card listed three real consequences (accounts gone, services
erroring, foreign keys broken), three alternatives (snapshot first / soft delete / scratch
copy), and a recommendation. Approving resumed the task and it executed. Cancelling made
it take a different route.

**3. It proposes a better route before spending steps.** For any task that looks like
real work, a planning pass runs first and returns a card with:

- the **recommended route** and why it beats the obvious one
- 3–6 concrete steps
- **alternative strategies**, each with its cost
- a **warning** if your stated approach is a trap (slow, fragile, deprecated)
- a **fastest** option if you want it in five minutes

The agent then executes the recommendation. If a step fails twice it is instructed to
switch routes rather than retry harder. Mid-task it can also call
`suggest_alternatives` to ask for better options on a sub-problem.

Turn the planner off with `PLAN_FIRST=0` in `.env` if you want raw speed.

**The honest limit:** the consent gate removes *silent* refusal and *permission-seeking*.
It cannot remove a model's trained refusal on genuinely harmful content — that lives in
the weights, not the prompt. If you approve and the model still declines, the app tells you
so plainly instead of pretending. On a local Ollama model you control the weights, so you
can pick an uncensored fine-tune if you want that. On Gemini or Groq you cannot. What you
get here is an agent that never stalls on legitimate work, never lectures, tells you the
real consequences before it acts, and always offers a way through.

## Still not there (the honest 20%)

Frontier-model depth, 3M-token context, 3,000+ OAuth integrations, parallel
sub-agent orchestration, mobile native apps, WhatsApp/Teams, enterprise
compliance. See the earlier breakdown — that's the platform, not the agent.

## Everyday commands

```bash
# start / stop the service
sudo systemctl start ninja-web@$USER
sudo systemctl stop ninja-web@$USER
journalctl -u ninja-web@$USER -f      # live logs

# reset the agent's workspace (nuclear)
rm -rf ~/ninja/workspace/*

# health check / self-repair
python app/repair.py --fix

# change your password
nano ~/ninja/.env     # edit NINJA_PASSWORD
sudo systemctl restart ninja-web@$USER

# wipe a VM back to clean
VBoxManage controlvm NinjaVM poweroff
VBoxManage snapshot NinjaVM restore clean-base
VBoxManage startvm NinjaVM --type headless
```

## Troubleshooting

**First move: `python app/repair.py --fix`.** It probes eleven things and fixes
the safe ones. If it can't fix something it tells you the exact command to run.

- **Can't reach it from phone** → is Tailscale on, on *both* devices? Same account?
- **Login loops** → cookies blocked? Try a normal browser tab, not private mode.
- **Agent does nothing** → `journalctl -u ninja-web@$USER -f`; check the model
  name in `.env` matches what `ollama list` shows.
- **`TypeError: Client.__init__() got an unexpected keyword argument 'proxies'`**
  → your `httpx` drifted to 0.28+. Fix: `.venv/bin/pip install "httpx>=0.27,<0.28"`.
  This is why `requirements.txt` pins it.
- **`error: address already in use`** → something else holds the port. Find it with
  `ss -ltnp | grep 8000` (or `sudo lsof -i :8000`), or change `PORT=` in `.env`.
- **`browse` fails with a Chromium sandbox error** → you're running as root.
  The tool already falls back to `--no-sandbox`, but a normal user is safer.
- **`web_search` returns "no results"** → DuckDuckGo sometimes serves a challenge
  page. The tool falls back to Bing automatically; if both fail you're offline.
- **Playwright errors** → `python -m playwright install --with-deps chromium`
- **Slow** → use `qwen2.5:3b` locally or switch to Groq free tier.
- **Out of disk** → `~/.cache/ms-playwright` is 1.2 GB and `~/.ollama` is ~5 GB.
  Both can be moved; see `OLLAMA_MODELS` and `PLAYWRIGHT_BROWSERS_PATH`.

