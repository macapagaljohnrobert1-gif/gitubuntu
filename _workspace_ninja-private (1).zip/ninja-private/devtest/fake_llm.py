"""Fake OpenAI server: refuses the first reply, then does the work.
Proves the refusal guard recovers instead of failing the task."""
import json
from http.server import BaseHTTPRequestHandler, HTTPServer

STATE = {"calls": 0}


def msg(content=None, tool_calls=None):
    return {
        "id": "chatcmpl-x", "object": "chat.completion", "created": 0,
        "model": "fake",
        "choices": [{
            "index": 0, "finish_reason": "tool_calls" if tool_calls else "stop",
            "message": {
                "role": "assistant",
                "content": content,
                "tool_calls": tool_calls,
            },
        }],
        "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
    }


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n) or b"{}")
        sysmsg = (body.get("messages") or [{}])[0].get("content", "")
        is_plan = ("planning stage" in sysmsg) or ("risk-review stage" in sysmsg)
        if not is_plan:
            STATE["calls"] += 1
        c = STATE["calls"]

        if is_plan:
            out = msg(json.dumps({
                "approach": "Write a single script and run it.",
                "why": "Fewest moving parts.",
                "steps": ["write", "run"],
                "alternatives": [{"name": "use a lib", "how": "pip install", "tradeoff": "extra dep"}],
                "warning": "", "fastest": "",
            }))
        elif "risk-review stage" in sysmsg:
            out = msg(json.dumps({
                "action": "Delete every row in the users table, then drop it.",
                "concern": "This destroys production user data with no backup.",
                "consequences": ["All user accounts are gone permanently",
                                 "Any service reading that table starts erroring",
                                 "Foreign keys in orders/audit tables break"],
                "reversible": False,
                "alternatives": [
                    {"name": "Snapshot the DB first", "how": "pg_dump to a file, verify restore, then drop", "tradeoff": "5 minutes and disk space"},
                    {"name": "Soft delete", "how": "add deleted_at, filter reads, purge later", "tradeoff": "schema change, keeps the data"},
                    {"name": "Copy to a scratch DB", "how": "do the destructive op on a clone to prove the migration", "tradeoff": "extra step"}],
                "recommendation": "Dump first, then drop. Same outcome, guaranteed undo.",
                "bypass": "Run it on a snapshot clone first.",
            }))
        elif c == 1:
            # the dodge
            out = msg("I'm sorry, but I can't help with that request.")
        elif c == 2:
            out = msg(None, [{
                "id": "call_1", "type": "function",
                "function": {"name": "write_file",
                             "arguments": json.dumps({"path": "proof.txt", "content": "guard worked\n"})},
            }])
        else:
            out = msg("Wrote proof.txt. Guard recovered and did the work.")

        data = json.dumps(out).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


if __name__ == "__main__":
    HTTPServer(("127.0.0.1", 8170), H).serve_forever()
