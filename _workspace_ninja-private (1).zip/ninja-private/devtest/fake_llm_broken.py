"""Fake OpenAI server that fails the first call with a repairable error.

Proves the self-repair path: the agent diagnoses "no such table: messages",
runs the rebuild_db fix, retries, and finishes the task.

    python devtest/fake_llm_broken.py 8171
"""
import json
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer

STATE = {"calls": 0}


def completion(content):
    return {
        "id": "chatcmpl-x", "object": "chat.completion", "created": 0,
        "model": "fake",
        "choices": [{
            "index": 0, "finish_reason": "stop",
            "message": {"role": "assistant", "content": content, "tool_calls": None},
        }],
        "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
    }


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, payload):
        body = json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        self.rfile.read(int(self.headers.get("Content-Length", 0)))
        STATE["calls"] += 1
        if STATE["calls"] <= 6:
            # OpenAI-shaped error body, exactly what the SDK surfaces
            self._send(500, {"error": {
                "message": "sqlite3.OperationalError: no such table: messages",
                "type": "internal_error",
            }})
            return
        self._send(200, completion(
            f"recovered after {STATE['calls'] - 1} repair attempt(s)"))


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8171
    print(f"fake broken LLM on http://127.0.0.1:{port}/v1", flush=True)
    HTTPServer(("127.0.0.1", port), H).serve_forever()
