"""Fake LLM that asks for a tool call which will fail, then reports.

Proves the agent attaches a self-repair diagnosis to a failing tool result.
"""
import json
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer

STATE = {"calls": 0}


def msg(content=None, tool_calls=None):
    return {
        "id": "chatcmpl-x", "object": "chat.completion", "created": 0,
        "model": "fake",
        "choices": [{
            "index": 0,
            "finish_reason": "tool_calls" if tool_calls else "stop",
            "message": {"role": "assistant", "content": content,
                        "tool_calls": tool_calls},
        }],
        "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
    }


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n) or b"{}")
        sysmsg = (body.get("messages") or [{}])[0].get("content", "")
        if "planning stage" in sysmsg or "risk-review stage" in sysmsg:
            payload = msg(json.dumps({"approach": "a", "why": "b", "steps": ["c"],
                                      "alternatives": [], "warning": "", "fastest": ""}))
        else:
            STATE["calls"] += 1
            if STATE["calls"] == 1:
                payload = msg(None, [{
                    "id": "call_1", "type": "function",
                    "function": {"name": "write_file",
                                 "arguments": json.dumps(
                                     {"path": "../../etc/passwd", "content": "x"})},
                }])
            else:
                payload = msg("done")
        data = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8311
    print(f"fake tool-error LLM on http://127.0.0.1:{port}/v1", flush=True)
    HTTPServer(("127.0.0.1", port), H).serve_forever()
