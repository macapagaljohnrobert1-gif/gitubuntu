#!/usr/bin/env bash
# One-shot installer for the private web app. Run inside the Ubuntu VM.
#   cd ~/ninja && chmod +x install.sh run.sh && ./install.sh
set -euo pipefail

APP_DIR="${APP_DIR:-$HOME/ninja}"
MIN_DISK_GB="${MIN_DISK_GB:-20}"

say() { printf '\n\033[1;32m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[!]\033[0m %s\n' "$*"; }
die() { printf '\033[1;31m[x]\033[0m %s\n' "$*" >&2; exit 1; }

# ---------------------------------------------------------------- preflight
say "Preflight checks"

[ "$(id -u)" -ne 0 ] || warn "Running as root. The service will still work, but a normal user is better."

if ! command -v python3 >/dev/null 2>&1; then
  die "python3 not found. Install it with: sudo apt-get install -y python3 python3-venv"
fi

PYV=$(python3 -c 'import sys;print("%d.%d"%sys.version_info[:2])')
case "$PYV" in
  3.10|3.11|3.12|3.13) say "Python $PYV — ok" ;;
  *) die "Python $PYV is not supported. Need 3.10–3.13." ;;
esac

AVAIL_GB=$(df -BG --output=avail "$HOME" | tail -1 | tr -dc '0-9')
if [ "${AVAIL_GB:-0}" -lt "$MIN_DISK_GB" ]; then
  die "Only ${AVAIL_GB}GB free on \$HOME. Need at least ${MIN_DISK_GB}GB (Chromium alone is 1.2GB, the model 4.7GB)."
fi
say "Disk: ${AVAIL_GB}GB free — ok"

RAM_GB=$(( $(awk '/MemTotal/{print $2}' /proc/meminfo) / 1024 / 1024 ))
if [ "$RAM_GB" -lt 7 ]; then
  warn "Only ${RAM_GB}GB RAM. A 7B model needs ~5GB and will swap badly."
  warn "Either raise the VM to 8GB or switch to qwen2.5:3b after install."
fi

# ---------------------------------------------------------------- packages
say "Installing system packages"
sudo apt-get update -y
sudo apt-get install -y python3 python3-venv python3-pip curl unzip ca-certificates \
  libnss3 libatk1.0-0 libatk-bridge2.0-0 libcups2 libdrm2 libxkbcommon0 \
  libxcomposite1 libxdamage1 libxfixes3 libxrandr2 libgbm1 libpango-1.0-0 \
  libcairo2 libasound2t64 2>/dev/null || \
sudo apt-get install -y libasound2

# ---------------------------------------------------------------- app files
say "Installing app into $APP_DIR"
mkdir -p "$APP_DIR"
for item in app static requirements.txt .env.example install.sh run.sh ninja-web.service README.md; do
  [ -e "$item" ] && cp -r "$item" "$APP_DIR"/ || true
done
cd "$APP_DIR"
mkdir -p data workspace

# ---------------------------------------------------------------- venv
say "Creating virtualenv and installing Python dependencies"
python3 -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
pip install --upgrade pip -q
pip install -r requirements.txt

say "Installing Chromium for the browse tool (1.2GB, be patient)"
python -m playwright install --with-deps chromium

# ---------------------------------------------------------------- .env
if [ ! -f .env ]; then
  cp .env.example .env
  PW=$(python3 -c "import secrets;print(secrets.token_urlsafe(18))")
  sed -i "s|^NINJA_PASSWORD=.*|NINJA_PASSWORD=$PW|" .env
  sed -i "s|YOURUSER|$USER|g" .env
  printf '\n\033[1;36m================================================\n'
  printf ' YOUR PASSWORD: %s\n' "$PW"
  printf ' (also saved in %s/.env)\n' "$APP_DIR"
  printf '================================================\033[0m\n'
else
  say "Keeping existing .env (delete it to regenerate the password)"
fi

# ---------------------------------------------------------------- ollama
say "Installing Ollama (local, offline, free)"
if ! command -v ollama >/dev/null 2>&1; then
  curl -fsSL https://ollama.com/install.sh | sh
fi
sudo systemctl enable --now ollama 2>/dev/null || true
sleep 2

MODEL=$(grep -E '^LLM_MODEL=' .env | cut -d= -f2-)
MODEL="${MODEL:-qwen2.5:7b}"
say "Pulling model: $MODEL (4-5GB, one time)"
if ! ollama pull "$MODEL"; then
  warn "Could not pull $MODEL. Falling back to qwen2.5:3b (smaller, weaker)."
  ollama pull qwen2.5:3b
  sed -i "s|^LLM_MODEL=.*|LLM_MODEL=qwen2.5:3b|" .env
fi

# ---------------------------------------------------------------- smoke test
say "Smoke test"
set -a; . ./.env; set +a
PORT="${PORT:-8000}"
PYTHONPATH=app python app/server.py > /tmp/ninja-smoke.log 2>&1 &
SRV=$!
trap 'kill $SRV 2>/dev/null || true' EXIT
sleep 6

if curl -fsS "http://127.0.0.1:${PORT}/api/health" >/tmp/ninja-health.json 2>/dev/null; then
  say "Health: $(cat /tmp/ninja-health.json)"
else
  warn "Server did not answer on port ${PORT}. Log follows:"
  cat /tmp/ninja-smoke.log
  die "Install finished but the app did not start. Fix the error above."
fi

CODE=$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:${PORT}/api/conversations")
[ "$CODE" = "401" ] && say "Auth gate: unauthenticated request correctly rejected (401)" \
                    || warn "Auth gate returned $CODE, expected 401"

kill $SRV 2>/dev/null || true
trap - EXIT

# ------------------------------------------------------------- self-repair
say "Self-check"
PYTHONPATH=app ./.venv/bin/python app/repair.py --fix || \
  warn "Some checks are still failing. Run 'python app/repair.py' to see them."

printf '\n\033[1;32m================================================\n'
printf ' Installed. Start it with:\n'
printf '   cd %s && ./run.sh\n' "$APP_DIR"
printf ' Then open http://127.0.0.1:%s\n' "$PORT"
printf '================================================\033[0m\n\n'
