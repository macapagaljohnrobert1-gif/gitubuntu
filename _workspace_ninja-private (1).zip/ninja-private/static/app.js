const $ = (s) => document.querySelector(s);
let convId = null;
let busy = false;

/* ---------------- auth ---------------- */
async function boot() {
  const me = await fetch('/api/me').then(r => r.json()).catch(() => ({ authed: false }));
  if (me.authed) enter();
}

$('#loginform').addEventListener('submit', async (e) => {
  e.preventDefault();
  const r = await fetch('/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password: $('#pw').value }),
  });
  if (r.ok) { $('#loginerr').textContent = ''; enter(); }
  else { $('#loginerr').textContent = 'Wrong password.'; $('#pw').value = ''; }
});

async function enter() {
  $('#login').classList.add('hidden');
  $('#app').classList.add('on');
  const h = await fetch('/api/health').then(r => r.json()).catch(() => ({}));
  $('#modelname').textContent = h.model || 'unknown';
  await loadConvs();
  await loadFiles();
  await loadMemory();
}

/* ---------------- right panel tabs ---------------- */
document.querySelectorAll('.right .tab').forEach(t => {
  t.onclick = () => {
    document.querySelectorAll('.right .tab').forEach(x => x.classList.remove('on'));
    document.querySelectorAll('.right .panel').forEach(x => x.classList.remove('on'));
    t.classList.add('on');
    $('#panel-' + t.dataset.panel).classList.add('on');
    if (t.dataset.panel === 'learned') loadMemory();
  };
});

/* ---------------- conversations ---------------- */
async function loadConvs() {
  const list = await fetch('/api/conversations').then(r => r.json()).catch(() => []);
  const box = $('#convs');
  box.innerHTML = '';
  if (!list.length) {
    box.innerHTML = '<div class="empty">No tasks yet</div>';
    return;
  }
  for (const c of list) {
    const d = document.createElement('div');
    d.className = 'conv' + (c.id === convId ? ' active' : '');
    d.innerHTML = `<span></span><span class="x">✕</span>`;
    d.querySelector('span').textContent = c.title || 'Untitled';
    d.onclick = (ev) => {
      if (ev.target.classList.contains('x')) { delConv(c.id); return; }
      openConv(c.id);
    };
    box.appendChild(d);
  }
}

async function newConv() {
  const r = await fetch('/api/conversations', { method: 'POST' }).then(r => r.json());
  convId = r.id;
  $('#wrap').innerHTML = '';
  $('#title').textContent = 'New task';
  await loadConvs();
  $('#input').focus();
}

async function delConv(id) {
  await fetch(`/api/conversations/${id}`, { method: 'DELETE' });
  if (id === convId) { convId = null; $('#wrap').innerHTML = ''; $('#title').textContent = 'New task'; }
  await loadConvs();
}

async function openConv(id) {
  convId = id;
  const data = await fetch(`/api/conversations/${id}/messages`).then(r => r.json());
  $('#wrap').innerHTML = '';
  const convs = await fetch('/api/conversations').then(r => r.json());
  const c = convs.find(x => x.id === id);
  $('#title').textContent = c ? c.title : 'Task';

  // replay stored events
  for (const ev of data.events || []) {
    try { render(JSON.parse(ev.payload), true); } catch (e) {}
  }
  await loadConvs();
  scrollDown();
}

/* ---------------- chat ---------------- */
const input = $('#input');
input.addEventListener('input', () => {
  input.style.height = 'auto';
  input.style.height = Math.min(input.scrollHeight, 160) + 'px';
  $('#send').disabled = busy || !input.value.trim();
});
input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
});
$('#send').onclick = send;
$('#newtask').onclick = newConv;
$('#refresh').onclick = loadFiles;
$('#memrefresh').onclick = loadMemory;

async function send() {
  const text = input.value.trim();
  if (!text || busy) return;
  if (!convId) await newConv();

  busy = true;
  $('#send').disabled = true;
  $('#statuspill').textContent = 'working';
  $('#statuspill').classList.add('live');

  addUser(text);
  input.value = '';
  input.style.height = 'auto';

  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ conv_id: convId, message: text }),
    });
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = '';
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      const parts = buf.split('\n\n');
      buf = parts.pop();
      for (const p of parts) {
        if (!p.startsWith('data: ')) continue;
        let ev;
        try { ev = JSON.parse(p.slice(6)); } catch (e) { continue; }
        if (ev.type === 'end') continue;
        render(ev);
      }
    }
  } catch (e) {
    render({ type: 'error', text: String(e) });
  }

  busy = false;
  $('#send').disabled = !input.value.trim();
  $('#statuspill').textContent = 'idle';
  $('#statuspill').classList.remove('live');
  await loadConvs();
  await loadFiles();
  await loadMemory();
}

/* ---------------- rendering ---------------- */
function addUser(text) {
  const d = document.createElement('div');
  d.className = 'msg user';
  d.innerHTML = '<div class="bubble"></div>';
  d.querySelector('.bubble').textContent = text;
  $('#wrap').appendChild(d);
  scrollDown();
}

function render(ev, replay = false) {
  const wrap = $('#wrap');

  if (ev.type === 'step') {
    const d = document.createElement('div');
    d.className = 'step';
    d.textContent = `step ${ev.n}/${ev.max}`;
    wrap.appendChild(d);
  }

  else if (ev.type === 'tool') {
    const d = document.createElement('div');
    d.className = 'tool';
    const args = JSON.stringify(ev.args || {});
    d.innerHTML = `<div class="head"><span class="nm"></span><span class="args"></span></div>
                   <div class="out"></div>`;
    d.querySelector('.nm').textContent = ev.name;
    d.querySelector('.args').textContent = args.length > 90 ? args.slice(0, 90) + '…' : args;
    d.querySelector('.head').onclick = () => d.classList.toggle('open');
    d.dataset.tool = ev.name;
    wrap.appendChild(d);
  }

  else if (ev.type === 'tool_result') {
    const tools = wrap.querySelectorAll('.tool');
    const last = tools[tools.length - 1];
    if (last) last.querySelector('.out').textContent = ev.result || '(no output)';
  }

  else if (ev.type === 'consent') {
    const b = ev.brief || {};
    const d = document.createElement('div');
    d.className = 'consent';
    const cons = (b.consequences || []).map(c => `<li>${esc(c)}</li>`).join('');
    const alts = (b.alternatives || []).map((a, i) =>
      `<label class="alt"><input type="radio" name="alt-${uid()}" value="${esc(a.name + ' — ' + (a.how||''))}">
        <span><b>${esc(a.name)}</b> ${esc(a.how || '')}
        ${a.tradeoff ? `<span class="cost">cost: ${esc(a.tradeoff)}</span>` : ''}</span></label>`).join('');

    d.innerHTML = `<div class="chead"><span class="tag">needs your call</span></div>
      <div class="cact"></div>
      ${b.concern ? '<div class="cconcern"></div>' : ''}
      ${cons ? '<div class="lbl">If it goes wrong</div><ul class="ccons">' + cons + '</ul>' : ''}
      ${b.reversible === false ? '<div class="irrev">not reversible</div>' : ''}
      ${alts ? '<div class="lbl">Ways to get there anyway</div><div class="calts">' + alts + '</div>' : ''}
      ${b.recommendation ? '<div class="crec"></div>' : ''}
      <div class="cbtns">
        <button class="go">Proceed</button>
        <button class="no">Cancel</button>
      </div>`;
    d.querySelector('.cact').textContent = b.action || '';
    if (b.concern) d.querySelector('.cconcern').textContent = b.concern;
    if (b.recommendation) d.querySelector('.crec').textContent = '↳ ' + b.recommendation;

    const decide = async (decision) => {
      const picked = d.querySelector('input[type=radio]:checked');
      const r = await fetch('/api/consent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conv_id: convId, decision,
          action: b.action || '', consequences: b.consequences || [],
          chosen: picked ? picked.value : '',
        }),
      }).then(r => r.json()).catch(() => null);
      d.classList.add('decided');
      d.querySelectorAll('button').forEach(x => x.disabled = true);
      d.querySelector('.cbtns').innerHTML =
        `<span class="verdict ${decision}">${decision === 'approved' ? '✓ approved' : '✕ cancelled'}</span>`;
      if (r && r.resume) {
        $('#input').value = r.resume;
        send();
      }
    };
    d.querySelector('.go').onclick = () => decide('approved');
    d.querySelector('.no').onclick = () => decide('declined');
    wrap.appendChild(d);
  }

  else if (ev.type === 'consent_decision') {
    const d = document.createElement('div');
    d.className = 'nudge';
    d.textContent = '· consent ' + (ev.decision || '');
    wrap.appendChild(d);
  }

  else if (ev.type === 'plan') {
    const p = ev.plan || {};
    const d = document.createElement('div');
    d.className = 'plan';
    let alts = '';
    if ((p.alternatives || []).length) {
      alts = '<div class="alts"><div class="lbl">Other routes</div>' +
        p.alternatives.map(a =>
          `<div class="alt"><b>${esc(a.name)}</b> ${esc(a.how || '')}` +
          (a.tradeoff ? `<span class="cost">cost: ${esc(a.tradeoff)}</span>` : '') +
          `</div>`).join('') + '</div>';
    }
    d.innerHTML = `<div class="phead"><span class="tag">plan</span><span class="route"></span></div>
      <div class="why"></div>
      <ol class="steps"></ol>
      ${p.warning ? '<div class="warn"></div>' : ''}
      ${p.fastest ? '<div class="fast"></div>' : ''}
      ${alts}`;
    d.querySelector('.route').textContent = p.approach || '';
    d.querySelector('.why').textContent = p.why || '';
    d.querySelector('.steps').innerHTML = (p.steps || []).map(s => `<li>${esc(s)}</li>`).join('');
    if (p.warning) d.querySelector('.warn').textContent = '⚠ ' + p.warning;
    if (p.fastest) d.querySelector('.fast').textContent = '⏱ ' + p.fastest;
    wrap.appendChild(d);
  }

  else if (ev.type === 'nudge') {
    const d = document.createElement('div');
    d.className = 'nudge';
    d.textContent = '↻ ' + (ev.text || 'retrying');
    wrap.appendChild(d);
  }

  else if (ev.type === 'memory') {
    const d = document.createElement('div');
    d.className = 'memnudge';
    d.innerHTML = '<span class="ic">\u2726</span><span class="tx"></span>';
    const lines = String(ev.text || '').split('\n').filter(l => /^(WHAT YOU KNOW|RELEVANT SKILLS|MISTAKES YOU)/.test(l));
    d.querySelector('.tx').textContent = lines.length
      ? 'recalled ' + lines.map(l => l.replace(/:$/, '').toLowerCase()).join(' \u00b7 ')
      : 'recalled memory';
    wrap.appendChild(d);
  }

  else if (ev.type === 'text' || ev.type === 'done') {
    const d = document.createElement('div');
    d.className = 'msg agent';
    d.innerHTML = '<div class="who">MyNinja</div><div class="body"></div>';
    d.querySelector('.body').textContent = ev.text || '';
    wrap.appendChild(d);
  }

  else if (ev.type === 'repair') {
    const d = ev.diag || {};
    const fixed = d.applied ? 'fixed' : (d.auto ? 'fix available' : 'no auto-fix');
    const el = document.createElement('div');
    el.className = 'tool repair' + (d.applied ? ' ok' : '');
    el.innerHTML = `<div class="head"><span class="nm">self-repair</span>
                    <span class="args"></span></div>
                    <div class="out"></div>`;
    el.querySelector('.args').textContent = fixed;
    el.querySelector('.out').textContent =
      `cause: ${d.cause || 'unknown'}\nfix:   ${d.fix || '-'}` +
      (d.detail ? `\nresult: ${d.detail}` : '');
    el.querySelector('.head').onclick = () => el.classList.toggle('open');
    wrap.appendChild(el);
  }

  else if (ev.type === 'error') {    const d = document.createElement('div');
    d.className = 'tool err';
    d.innerHTML = `<div class="head"><span class="nm">error</span></div>
                   <div class="out" style="display:block"></div>`;
    d.querySelector('.out').textContent = ev.text || 'unknown error';
    wrap.appendChild(d);
  }

  if (!replay) scrollDown();
}

function scrollDown() {
  const s = $('#stream');
  s.scrollTop = s.scrollHeight;
}

/* ---------------- memory (self-evolution) ---------------- */
async function loadMemory() {
  const data = await fetch('/api/memory').then(r => r.json()).catch(() => null);
  const box = $('#memlist');
  if (!data) { box.innerHTML = '<div class="mem-empty">Could not load memory.</div>'; return; }

  const st = data.stats || {};
  const total = (st.skills || 0) + (st.preferences || 0) + (st.lessons || 0);
  $('#memcount').textContent = total;

  let html = '';

  const prefs = data.preferences || [];
  html += '<div class="mem-sec"><h4>Preferences</h4>';
  if (!prefs.length) html += '<div class="mem-empty">Nothing yet. Tell it \u201cI prefer X\u201d and it will remember.</div>';
  for (const p of prefs) {
    html += `<div class="mem-item" data-kind="pref" data-key="${esc(p.key)}">
      <span class="t">${esc(p.key)}</span>
      <span class="b">${esc(p.value)}</span>
      <button class="del" title="Forget">\u2715</button></div>`;
  }
  html += '</div>';

  const skills = data.skills || [];
  html += '<div class="mem-sec"><h4>Skills</h4>';
  if (!skills.length) html += '<div class="mem-empty">No skills learned yet. It saves one after a task it solved well.</div>';
  for (const s of skills) {
    html += `<div class="mem-item" data-kind="skill" data-key="${esc(s.name)}">
      <span class="t">${esc(s.name)}</span>
      <span class="b">${esc(s.trigger)}</span>
      <div class="meta">used ${s.uses}\u00d7 \u00b7 worked ${s.wins}\u00d7</div>
      <button class="del" title="Forget">\u2715</button></div>`;
  }
  html += '</div>';

  const lessons = data.lessons || [];
  html += '<div class="mem-sec"><h4>Lessons</h4>';
  if (!lessons.length) html += '<div class="mem-empty">No mistakes recorded. Good.</div>';
  for (const l of lessons) {
    html += `<div class="mem-item" data-kind="lesson" data-key="${esc(l.signature)}">
      <span class="t">${esc(l.mistake)}</span>
      <span class="b">\u2192 ${esc(l.fix)}</span>
      <div class="meta">hit ${l.hits}\u00d7</div></div>`;
  }
  html += '</div>';

  // ---- health / self-repair ----
  html += '<div class="mem-sec"><h4>Health</h4><div id="healthbox">checking\u2026</div></div>';

  box.innerHTML = html;
  loadHealth();

  box.querySelectorAll('.del').forEach(b => {
    b.onclick = async (e) => {
      e.stopPropagation();
      const item = b.closest('.mem-item');
      const kind = item.dataset.kind;
      const key = item.dataset.key;
      if (kind === 'pref') await fetch(`/api/memory/preference/${encodeURIComponent(key)}`, { method: 'DELETE' });
      else if (kind === 'skill') await fetch(`/api/memory/skill/${encodeURIComponent(key)}`, { method: 'DELETE' });
      else await fetch(`/api/memory/lesson/${encodeURIComponent(key)}`, { method: 'DELETE' });
      loadMemory();
    };
  });
}

/* ---------------- health / self-repair ---------------- */
async function loadHealth() {
  const box = $('#healthbox');
  if (!box) return;
  const [rep, hist] = await Promise.all([
    fetch('/api/health/deep').then(r => r.json()).catch(() => null),
    fetch('/api/repairs?limit=6').then(r => r.json()).catch(() => ({ repairs: [] })),
  ]);
  if (!rep) { box.innerHTML = '<div class="mem-empty">Could not read health.</div>'; return; }

  const bad = (rep.checks || []).filter(c => !c.ok);
  let html = `<div class="health-sum ${rep.healthy ? 'good' : 'bad'}">
    ${rep.healthy ? 'All checks passing' : bad.length + ' check(s) failing'}
    <button id="runrepair">${bad.length ? 'Repair' : 'Re-check'}</button>
  </div>`;

  for (const c of bad) {
    html += `<div class="mem-item"><span class="t">${esc(c.name)}</span>
      <span class="b">${esc(c.detail)}</span>
      <div class="meta">${c.fix_id ? 'fix: ' + esc(c.fix_id) : 'manual'}</div></div>`;
  }

  const rows = (hist.repairs || []);
  if (rows.length) {
    html += '<div class="health-log"><h5>Recent repairs</h5>';
    for (const r of rows) {
      const when = new Date(r.ts * 1000).toLocaleString();
      html += `<div class="rep-row ${r.ok ? 'ok' : 'no'}">
        <span>${r.ok ? '\u2713' : '\u2715'} ${esc(r.fix_id)}</span>
        <span class="when">${esc(when)}</span></div>`;
    }
    html += '</div>';
  }

  box.innerHTML = html;
  const btn = $('#runrepair');
  if (btn) btn.onclick = async () => {
    btn.disabled = true;
    btn.textContent = 'working\u2026';
    await fetch('/api/repair', { method: 'POST' });
    loadHealth();
    loadMemory();
  };
}

let _uid = 0;function uid() { return ++_uid; }

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/* ---------------- files ---------------- */
async function loadFiles() {
  const data = await fetch('/api/files?path=.').then(r => r.json()).catch(() => ({ entries: [] }));
  const box = $('#filelist');
  box.innerHTML = '';
  const entries = (data.entries || []).filter(e => !e.name.startsWith('.'));
  if (!entries.length) {
    box.innerHTML = '<div class="empty">Nothing yet.<br>Ask it to build something.</div>';
    return;
  }
  for (const e of entries) {
    const d = document.createElement('div');
    d.className = 'fitem';
    d.innerHTML = `<span class="ic">${e.dir ? '▸' : '·'}</span>
                   <span class="nm"></span><span class="sz">${e.dir ? '' : fmt(e.size)}</span>`;
    d.querySelector('.nm').textContent = e.name;
    if (!e.dir) d.onclick = () => preview(e.path, e.name);
    box.appendChild(d);
  }
}

function fmt(n) {
  if (n < 1024) return n + 'B';
  if (n < 1048576) return (n / 1024).toFixed(0) + 'K';
  return (n / 1048576).toFixed(1) + 'M';
}

async function preview(path, name) {
  $('#modalname').textContent = name;
  $('#dl').href = `/api/files/download?path=${encodeURIComponent(path)}`;
  $('#modalbody').textContent = 'loading…';
  $('#modal').classList.add('on');
  const r = await fetch(`/api/files/raw?path=${encodeURIComponent(path)}`);
  const j = await r.json();
  $('#modalbody').textContent = j.content ?? j.error ?? '(empty)';
}

$('#close').onclick = (e) => { e.preventDefault(); $('#modal').classList.remove('on'); };
$('#modal').onclick = (e) => { if (e.target.id === 'modal') $('#modal').classList.remove('on'); };

boot();
