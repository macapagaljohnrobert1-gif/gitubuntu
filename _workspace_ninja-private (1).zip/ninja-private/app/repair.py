"""Self-diagnosis and self-repair for MyNinja.

Three entry points:

    check_all()          -> Report        probe the install, change nothing
    repair_all(report)   -> Report        run the safe fixes for failed checks
    diagnose_error(text) -> dict          map a runtime error to a cause + fix
    heal_error(text)     -> dict          diagnose, then apply the fix if safe

Design rules, in order of importance:

1. Idempotent.  Every fix may be run any number of times. Running the whole
   repair pass twice in a row must be a no-op the second time.
2. Bounded.  Each fix has a hard timeout and a single attempt per process.
   A repair that hangs is worse than the fault it was fixing.
3. Conservative.  Only fixes in SAFE_FIXES run automatically. Anything that
   could destroy user data (dropping tables, deleting the workspace) is
   detected and reported, never executed.
4. Auditable.  Every repair writes a row to the `repairs` table and a lesson
   to the memory store, so the agent remembers what broke and what fixed it.

Run it directly for a health report:

    python app/repair.py            # report only
    python app/repair.py --fix      # report, then repair
    python app/repair.py --json     # machine readable
"""
from __future__ import annotations

import json
import os
import re
import shutil
import socket
import sqlite3
import subprocess
import sys
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
ROOT = APP_DIR.parent
DB_PATH = Path(os.getenv("NINJA_DB", str(ROOT / "data" / "ninja.db")))
WORKDIR = Path(os.getenv("NINJA_WORKDIR", str(ROOT / "workspace")))
LOG_DIR = ROOT / "data" / "logs"

PORT = int(os.getenv("PORT", "8000"))
BASE_URL = os.getenv("LLM_BASE_URL", "http://localhost:11434/v1")
MODEL = os.getenv("LLM_MODEL", "qwen2.5:7b")

# One attempt per fix per process. Prevents a repair loop from spinning.
_ATTEMPTED: set[str] = set()

REQUIRED_TABLES = (
    "conversations", "messages", "events",
    "skills", "preferences", "lessons", "sessions",
)


# ---------------------------------------------------------------- data types

@dataclass
class Check:
    name: str
    ok: bool
    detail: str
    fixable: bool = False
    fix_id: str | None = None
    severity: str = "warn"          # info | warn | fatal

    def as_dict(self) -> dict:
        return asdict(self)


@dataclass
class Report:
    checks: list[Check] = field(default_factory=list)
    repaired: list[str] = field(default_factory=list)
    failed_fixes: list[str] = field(default_factory=list)

    @property
    def healthy(self) -> bool:
        return all(c.ok for c in self.checks)

    @property
    def fatal(self) -> list[Check]:
        return [c for c in self.checks if not c.ok and c.severity == "fatal"]

    def as_dict(self) -> dict:
        return {
            "healthy": self.healthy,
            "fatal": len(self.fatal),
            "checks": [c.as_dict() for c in self.checks],
            "repaired": self.repaired,
            "failed_fixes": self.failed_fixes,
        }

    def summary(self) -> str:
        bad = [c for c in self.checks if not c.ok]
        if not bad:
            line = f"all {len(self.checks)} checks passed"
        else:
            line = f"{len(bad)} of {len(self.checks)} checks failed: " + \
                   ", ".join(c.name for c in bad)
        if self.repaired:
            line += f" | repaired: {', '.join(self.repaired)}"
        if self.failed_fixes:
            line += f" | could not fix: {', '.join(self.failed_fixes)}"
        return line


# ------------------------------------------------------------------ helpers

def _run(cmd: list[str], timeout: int = 120) -> tuple[int, str]:
    """Run a command, never raise. Returns (exit_code, combined_output)."""
    try:
        p = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout,
            cwd=str(ROOT),
        )
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except FileNotFoundError:
        return 127, f"{cmd[0]}: not found"
    except subprocess.TimeoutExpired:
        return 124, f"{cmd[0]}: timed out after {timeout}s"
    except Exception as e:  # noqa: BLE001
        return 1, f"{cmd[0]}: {e}"


def _port_open(host: str, port: int, timeout: float = 1.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _pip() -> list[str]:
    """Prefer the venv's pip if the server was installed the normal way."""
    for cand in (ROOT / "venv" / "bin" / "python", ROOT / ".venv" / "bin" / "python"):
        if cand.exists():
            return [str(cand), "-m", "pip"]
    return [sys.executable, "-m", "pip"]


# ------------------------------------------------------------------- checks

def _check_python() -> Check:
    v = sys.version_info
    ok = (3, 10) <= (v.major, v.minor) <= (3, 13)
    return Check(
        "python", ok, f"{v.major}.{v.minor}.{v.micro}",
        severity="fatal" if not ok else "info",
    )


def _check_deps() -> Check:
    missing = []
    for mod in ("fastapi", "uvicorn", "openai", "httpx", "playwright", "bs4"):
        try:
            __import__(mod)
        except Exception:  # noqa: BLE001
            missing.append(mod)
    return Check(
        "dependencies", not missing,
        "all present" if not missing else "missing: " + ", ".join(missing),
        fixable=bool(missing), fix_id="pip_install",
        severity="fatal" if missing else "info",
    )


def _check_httpx_pin() -> Check:
    """openai<1.55 + httpx>=0.28 raises TypeError on 'proxies'.

    This is the single most common broken install, because pip resolves
    both to their newest versions unless something pins them apart.
    """
    try:
        import httpx
        import openai
    except Exception as e:  # noqa: BLE001
        return Check("httpx_pin", False, f"cannot import: {e}",
                     fixable=True, fix_id="pin_httpx", severity="fatal")

    hv = httpx.__version__
    ov = openai.__version__
    h_major, h_minor = (int(x) for x in hv.split(".")[:2])
    o_major, o_minor = (int(x) for x in ov.split(".")[:2])

    # httpx 0.28 dropped the `proxies` kwarg; openai only stopped passing it
    # from 1.55 onwards.
    bad = (h_major, h_minor) >= (0, 28) and (o_major, o_minor) < (1, 55)
    detail = f"openai {ov} / httpx {hv}"
    if bad:
        detail += " — incompatible, will raise TypeError on 'proxies'"
    return Check("httpx_pin", not bad, detail,
                 fixable=bad, fix_id="pin_httpx",
                 severity="fatal" if bad else "info")


def _check_dirs() -> Check:
    missing = [str(d) for d in (DB_PATH.parent, WORKDIR, LOG_DIR) if not d.exists()]
    return Check(
        "directories", not missing,
        "present" if not missing else "missing: " + ", ".join(missing),
        fixable=bool(missing), fix_id="make_dirs",
    )


def _check_db() -> Check:
    if not DB_PATH.exists():
        return Check("database", False, f"{DB_PATH} does not exist",
                     fixable=True, fix_id="rebuild_db", severity="fatal")
    try:
        conn = sqlite3.connect(DB_PATH, timeout=5)
        res = conn.execute("PRAGMA integrity_check").fetchone()
        conn.close()
        ok = bool(res and res[0] == "ok")
        return Check("database", ok, res[0] if res else "no result",
                     fixable=not ok, fix_id="rebuild_db",
                     severity="fatal" if not ok else "info")
    except Exception as e:  # noqa: BLE001
        return Check("database", False, f"{type(e).__name__}: {e}",
                     fixable=True, fix_id="rebuild_db", severity="fatal")


def _check_tables() -> Check:
    if not DB_PATH.exists():
        return Check("schema", False, "database missing", fixable=True, fix_id="rebuild_db")
    try:
        conn = sqlite3.connect(DB_PATH, timeout=5)
        have = {r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        conn.close()
    except Exception as e:  # noqa: BLE001
        return Check("schema", False, f"{type(e).__name__}: {e}",
                     fixable=True, fix_id="rebuild_db")
    missing = [t for t in REQUIRED_TABLES if t not in have]
    return Check(
        "schema", not missing,
        "complete" if not missing else "missing tables: " + ", ".join(missing),
        fixable=bool(missing), fix_id="rebuild_db",
        severity="fatal" if missing else "info",
    )


def _check_disk() -> Check:
    try:
        free_gb = shutil.disk_usage(str(ROOT)).free / 1e9
    except Exception as e:  # noqa: BLE001
        return Check("disk", False, str(e))
    ok = free_gb >= 1.0
    return Check("disk", ok, f"{free_gb:.1f} GB free",
                 fixable=not ok, fix_id="clean_caches",
                 severity="warn" if not ok else "info")


def _check_port() -> Check:
    """Port in use is only a fault if it's not *us* already listening."""
    in_use = _port_open("127.0.0.1", PORT)
    return Check("port", True,
                 f"{PORT} in use (fine if that is this server)" if in_use
                 else f"{PORT} free")


def _check_model() -> Check:
    """Is the model endpoint reachable at all?"""
    from urllib.parse import urlparse
    u = urlparse(BASE_URL)
    host = u.hostname or "localhost"
    port = u.port or (443 if u.scheme == "https" else 80)
    if not _port_open(host, port, timeout=2.0):
        return Check("model_endpoint", False,
                     f"{host}:{port} not reachable ({MODEL})",
                     fixable=True, fix_id="start_ollama")
    return Check("model_endpoint", True, f"{host}:{port} reachable ({MODEL})")


def _check_chromium() -> Check:
    try:
        from playwright.sync_api import sync_playwright
    except Exception as e:  # noqa: BLE001
        return Check("chromium", False, f"playwright missing: {e}",
                     fixable=True, fix_id="install_chromium")
    try:
        with sync_playwright() as pw:
            path = pw.chromium.executable_path
            if not path or not Path(path).exists():
                return Check("chromium", False, "browser binary not downloaded",
                             fixable=True, fix_id="install_chromium")
            return Check("chromium", True, path)
    except Exception as e:  # noqa: BLE001
        return Check("chromium", False, f"{type(e).__name__}: {e}",
                     fixable=True, fix_id="install_chromium")


def _check_workspace_escape() -> Check:
    """The file tools must never resolve outside the workspace."""
    try:
        from tools import _safe_path  # type: ignore
    except Exception:  # noqa: BLE001
        return Check("workspace_sandbox", True, "resolver not importable, skipped")
    try:
        got = _safe_path("../../etc/passwd")
    except ValueError:
        # raising is the correct behaviour — the escape was refused
        return Check("workspace_sandbox", True, "escape refused")
    except Exception as e:  # noqa: BLE001
        return Check("workspace_sandbox", True, f"resolver raised {type(e).__name__}")
    inside = str(got).startswith(str(WORKDIR.resolve()))
    return Check("workspace_sandbox", inside,
                 "contained" if inside else "path escapes workspace",
                 severity="info" if inside else "fatal")


CHECKS = (
    _check_python,
    _check_deps,
    _check_httpx_pin,
    _check_dirs,
    _check_db,
    _check_tables,
    _check_disk,
    _check_port,
    _check_model,
    _check_chromium,
    _check_workspace_escape,
)


# -------------------------------------------------------------------- fixes

def _fix_pip_install() -> tuple[bool, str]:
    code, out = _run(_pip() + ["install", "-r", str(ROOT / "requirements.txt")], timeout=600)
    return code == 0, out[-800:]


def _fix_pin_httpx() -> tuple[bool, str]:
    code, out = _run(
        _pip() + ["install", "openai>=1.68,<2", "httpx>=0.27,<0.28"], timeout=300)
    return code == 0, out[-800:]


def _fix_dirs() -> tuple[bool, str]:
    made = []
    for d in (DB_PATH.parent, WORKDIR, LOG_DIR):
        if not d.exists():
            d.mkdir(parents=True, exist_ok=True)
            made.append(str(d))
    return True, "created: " + (", ".join(made) or "nothing to do")


def _fix_rebuild_db() -> tuple[bool, str]:
    """Create missing tables. Never drops data.

    store.init() and memory.init() are CREATE TABLE IF NOT EXISTS, so this is
    safe to run against a healthy database.
    """
    try:
        if DB_PATH.exists():
            conn = sqlite3.connect(DB_PATH, timeout=10)
            res = conn.execute("PRAGMA integrity_check").fetchone()
            conn.close()
            if not (res and res[0] == "ok"):
                # Corrupt file: move it aside, do not delete it.
                bad = DB_PATH.with_suffix(f".corrupt.{int(time.time())}")
                shutil.move(str(DB_PATH), str(bad))
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        import store
        import memory
        store.init()
        memory.init()
        return True, "schema created"
    except Exception as e:  # noqa: BLE001
        return False, f"{type(e).__name__}: {e}"


def _fix_clean_caches() -> tuple[bool, str]:
    freed = 0
    targets = [
        Path.home() / ".cache" / "pip",
        ROOT / "data" / "logs",
        Path("/tmp"),
    ]
    for t in targets:
        if not t.exists():
            continue
        if t == Path("/tmp"):
            # only our own stale test dirs, never the whole of /tmp
            for p in t.glob("ninja-*"):
                if p.is_dir():
                    freed += sum(f.stat().st_size for f in p.rglob("*") if f.is_file())
                    shutil.rmtree(p, ignore_errors=True)
            continue
        if t == ROOT / "data" / "logs":
            for f in t.glob("*.log"):
                if f.stat().st_size > 50 * 1024 * 1024:
                    freed += f.stat().st_size
                    f.unlink(missing_ok=True)
            continue
        freed += sum(f.stat().st_size for f in t.rglob("*") if f.is_file())
        shutil.rmtree(t, ignore_errors=True)
    return True, f"freed ~{freed / 1e6:.0f} MB"


def _fix_start_ollama() -> tuple[bool, str]:
    if shutil.which("ollama") is None:
        return False, "ollama is not installed — run install.sh"
    if _port_open("127.0.0.1", 11434):
        return True, "already running"
    try:
        subprocess.Popen(
            ["ollama", "serve"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except Exception as e:  # noqa: BLE001
        return False, f"{type(e).__name__}: {e}"
    for _ in range(20):
        if _port_open("127.0.0.1", 11434):
            return True, "started"
        time.sleep(0.5)
    return False, "started but did not answer on 11434"


def _fix_install_chromium() -> tuple[bool, str]:
    py = _pip()[:-2] if _pip()[-2:] == ["-m", "pip"] else [sys.executable]
    code, out = _run(py + ["-m", "playwright", "install", "chromium"], timeout=900)
    return code == 0, out[-800:]


FIXES = {
    "pip_install": _fix_pip_install,
    "pin_httpx": _fix_pin_httpx,
    "make_dirs": _fix_dirs,
    "rebuild_db": _fix_rebuild_db,
    "clean_caches": _fix_clean_caches,
    "start_ollama": _fix_start_ollama,
    "install_chromium": _fix_install_chromium,
}

# Everything here is non-destructive. If you add a fix that deletes user data,
# do NOT add it to this set — leave it manual.
SAFE_FIXES = set(FIXES)


# --------------------------------------------------------------- public API

def check_all() -> Report:
    report = Report()
    for fn in CHECKS:
        try:
            report.checks.append(fn())
        except Exception as e:  # noqa: BLE001
            report.checks.append(
                Check(fn.__name__.removeprefix("_check_"), False,
                      f"check crashed: {type(e).__name__}: {e}"))
    return report


def repair_all(report: Report | None = None, only: list[str] | None = None) -> Report:
    """Run the safe fixes for every failed, fixable check.

    Re-probes afterwards so the returned report reflects reality, not hope.
    """
    report = report or check_all()
    attempted: list[tuple[str, str, str]] = []   # (check_name, fix_id, detail)
    for check in report.checks:
        if check.ok or not check.fix_id:
            continue
        fix_id = check.fix_id
        if fix_id not in SAFE_FIXES:
            continue
        if only and fix_id not in only:
            continue
        if fix_id in _ATTEMPTED:
            continue
        _ATTEMPTED.add(fix_id)

        try:
            ok, detail = FIXES[fix_id]()
        except Exception as e:  # noqa: BLE001
            ok, detail = False, f"{type(e).__name__}: {e}"

        _record({
            "check": check.name,
            "fix_id": fix_id,
            "ok": ok,
            "detail": detail[:600],
        })
        attempted.append((check.name, fix_id, detail))

    if not attempted:
        return report

    # Re-probe everything and judge the repairs by what is true now, not by
    # whether the fix command exited zero. "clean_caches" can succeed and the
    # disk can still be full; that is not a repair.
    fresh = check_all()
    now = {c.name: c for c in fresh.checks}
    for name, fix_id, detail in attempted:
        cur = now.get(name)
        if cur is not None and cur.ok:
            report.repaired.append(f"{name} ({fix_id})")
        else:
            still = cur.detail if cur else "check disappeared"
            report.failed_fixes.append(f"{name} ({fix_id}): still failing — {still[:120]}")
    report.checks = fresh.checks
    return report


_NOISE = re.compile(r"[\u2500-\u257f\u2580-\u259f]|%\s*of\s*\d+\s*MiB")


def _clean(text: str, limit: int = 300) -> str:
    """Strip progress-bar noise so repair history stays readable."""
    lines = [ln.strip() for ln in (text or "").splitlines()]
    keep = [ln for ln in lines if ln and not _NOISE.search(ln)]
    out = " / ".join(keep[-3:]) if keep else (text or "").strip()
    return out[:limit]


def _record(entry: dict) -> None:
    """Persist a repair attempt and turn it into a reusable lesson."""
    entry["ts"] = int(time.time())
    entry["detail"] = _clean(entry.get("detail", ""))
    try:
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(DB_PATH, timeout=10)
        conn.execute(
            "CREATE TABLE IF NOT EXISTS repairs ("
            " id INTEGER PRIMARY KEY AUTOINCREMENT,"
            " ts INTEGER NOT NULL, check_name TEXT, fix_id TEXT,"
            " ok INTEGER, detail TEXT)"
        )
        conn.execute(
            "INSERT INTO repairs (ts, check_name, fix_id, ok, detail) VALUES (?,?,?,?,?)",
            (entry["ts"], entry["check"], entry["fix_id"],
             1 if entry["ok"] else 0, entry["detail"]),
        )
        conn.commit()
        conn.close()
    except Exception:  # noqa: BLE001
        pass

    if entry["ok"]:
        try:
            import memory
            mistake = entry.get("error") or f"{entry['check']} failed"
            memory.note_lesson(
                f"{mistake[:180]}",
                f"{entry['fix_id']} resolved it: {entry['detail'][:180]}",
            )
        except Exception:  # noqa: BLE001
            pass


def recent_repairs(limit: int = 20) -> list[dict]:
    try:
        conn = sqlite3.connect(DB_PATH, timeout=5)
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT ts, check_name, fix_id, ok, detail FROM repairs"
            " ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        conn.close()
        return [dict(r) for r in rows]
    except Exception:  # noqa: BLE001
        return []


# ------------------------------------------------------------ error triage

# Ordered: first match wins. Each entry is (regex, cause, fix, fix_id).
# `fix_id=None` means "there is no safe automatic fix, tell the operator".
PATTERNS: list[tuple[str, str, str, str | None]] = [
    (
        r"unexpected keyword argument 'proxies'",
        "openai and httpx versions are incompatible (httpx >= 0.28 dropped `proxies`)",
        "pin httpx below 0.28 and openai at or above 1.68",
        "pin_httpx",
    ),
    (
        r"No module named '?([\w.]+)'?",
        "a required Python package is not installed in the active interpreter",
        "reinstall from requirements.txt",
        "pip_install",
    ),
    (
        r"address already in use",
        "another process (probably a stale copy of this server) holds the port",
        "kill the old process or change PORT in .env",
        None,
    ),
    (
        r"no such table:?\s*(\w+)",
        "the database schema was never created, or the DB file was replaced",
        "create the missing tables",
        "rebuild_db",
    ),
    (
        r"database is locked",
        "a second writer holds the SQLite lock past the timeout",
        "close the duplicate process; SQLite allows one writer at a time",
        None,
    ),
    (
        r"disk I/O error|No space left on device|database or disk is full",
        "the disk is full or the filesystem went read-only",
        "clear caches and stale logs",
        "clean_caches",
    ),
    (
        r"Permission denied|EACCES|Operation not permitted",
        "the process lacks write access to the path it needs",
        "fix ownership of the install directory (chown -R $USER)",
        None,
    ),
    (
        r"Connection refused|Max retries exceeded|Failed to establish a new connection",
        "the model endpoint is not listening",
        "start the Ollama service",
        "start_ollama",
    ),
    (
        r"401|Unauthorized|invalid api key|Incorrect API key",
        "the API key is wrong or missing for this endpoint",
        "set LLM_API_KEY in .env",
        None,
    ),
    (
        r"404|model .* not found|does not support tool",
        "the configured model name does not exist on the endpoint",
        "pull the model (`ollama pull <name>`) or change LLM_MODEL",
        None,
    ),
    (
        r"Executable doesn't exist|playwright install|BrowserType\.launch",
        "the Playwright Chromium binary is missing",
        "download the browser",
        "install_chromium",
    ),
    (
        r"Timeout|timed out|ReadTimeout",
        "the operation exceeded its deadline — usually a cold model load or a slow page",
        "retry once; if it persists, raise the timeout or use a smaller model",
        None,
    ),
    (
        r"path escapes workspace",
        "a file tool was asked to touch something outside the sandbox",
        "the request was refused on purpose — rewrite the path relative to the workspace",
        None,
    ),
    (
        r"rate limit|429|quota|insufficient_quota",
        "the provider is throttling or the free quota is spent",
        "wait, or switch LLM_BASE_URL to a local Ollama model",
        None,
    ),
    (
        r"context length|too many tokens|maximum context",
        "the conversation outgrew the model's context window",
        "start a new conversation, or lower MAX_STEPS",
        None,
    ),
    (
        r"JSONDecodeError|Expecting value|invalid JSON",
        "the model emitted malformed tool arguments",
        "retry with the error in context; the loop already tolerates this",
        None,
    ),
]

_COMPILED = [(re.compile(p, re.I), cause, fix, fid)
             for p, cause, fix, fid in PATTERNS]


def diagnose_error(text: str) -> dict:
    """Map a raw error string to a cause, a fix, and whether we can auto-run it."""
    raw = (text or "").strip()
    for rx, cause, fix, fid in _COMPILED:
        if rx.search(raw):
            return {
                "matched": rx.pattern,
                "cause": cause,
                "fix": fix,
                "fix_id": fid,
                "auto": bool(fid and fid in SAFE_FIXES),
                "raw": raw[:500],
            }
    return {
        "matched": None,
        "cause": "unrecognised error",
        "fix": "read the traceback and adjust the approach",
        "fix_id": None,
        "auto": False,
        "raw": raw[:500],
    }


def heal_error(text: str) -> dict:
    """Diagnose, then apply the fix if it is safe and not already tried."""
    diag = diagnose_error(text)
    fid = diag.get("fix_id")
    if not (diag["auto"] and fid and fid not in _ATTEMPTED):
        diag["applied"] = False
        return diag
    _ATTEMPTED.add(fid)
    try:
        ok, detail = FIXES[fid]()
    except Exception as e:  # noqa: BLE001
        ok, detail = False, f"{type(e).__name__}: {e}"
    diag["applied"] = ok
    diag["detail"] = detail[:400]
    _record({"check": "runtime", "fix_id": fid, "ok": ok,
             "detail": detail[:600], "error": diag["raw"]})
    return diag


def format_for_prompt(diag: dict) -> str:
    """A compact block to inject into the message list after a failure."""
    lines = [
        "--- SELF-REPAIR ---",
        f"error: {diag.get('raw', '')[:300]}",
        f"cause: {diag.get('cause')}",
        f"fix:   {diag.get('fix')}",
    ]
    if diag.get("applied"):
        lines.append("status: repair applied — retry the same call now")
    elif diag.get("fix_id"):
        lines.append("status: repair not applied — change your approach, do not repeat the identical call")
    else:
        lines.append("status: no automatic repair — change your approach, do not repeat the identical call")
    lines.append("--- END SELF-REPAIR ---")
    return "\n".join(lines)


# ---------------------------------------------------------------------- CLI

def _main(argv: list[str]) -> int:
    as_json = "--json" in argv
    do_fix = "--fix" in argv

    report = check_all()
    if do_fix:
        report = repair_all(report)

    if as_json:
        print(json.dumps(report.as_dict(), indent=2))
    else:
        print(f"MyNinja self-check — {time.strftime('%Y-%m-%d %H:%M:%S')}")
        print("-" * 62)
        for c in report.checks:
            mark = "ok  " if c.ok else "FAIL"
            fix = f"  -> {c.fix_id}" if (not c.ok and c.fix_id) else ""
            print(f"[{mark}] {c.name:<18} {c.detail[:60]}{fix}")
        print("-" * 62)
        print(report.summary())

    return 0 if report.healthy else 1


if __name__ == "__main__":
    raise SystemExit(_main(sys.argv[1:]))
