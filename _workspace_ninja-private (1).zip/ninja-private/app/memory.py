"""Self-evolution: skills, preferences, and lessons that persist and compound.

Three stores:
  skills      - reusable procedures learned from completed tasks
  preferences - how you like things done (voice, format, stack choices)
  lessons     - failures + the fix, so the same mistake isn't repeated
"""
import os
import re
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path

DB_PATH = Path(os.getenv("NINJA_DB", str(Path(__file__).parent.parent / "data" / "ninja.db")))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

SCHEMA = """
CREATE TABLE IF NOT EXISTS skills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    trigger TEXT NOT NULL,
    body TEXT NOT NULL,
    uses INTEGER NOT NULL DEFAULT 0,
    wins INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS preferences (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key TEXT NOT NULL UNIQUE,
    value TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS lessons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    signature TEXT NOT NULL UNIQUE,
    mistake TEXT NOT NULL,
    fix TEXT NOT NULL,
    hits INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_skill_name ON skills(name);
"""


@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init():
    with db() as c:
        c.executescript(SCHEMA)


# ---------------- scoring (no heavy deps) ----------------

STOP = set("""a an the and or but if then else for to of in on at by with from is are was were
be been being do does did this that these those it its as into your you my me i we our can will
use using used make made get got how what when where which who why not no yes please""".split())


def _tokens(text: str) -> set[str]:
    words = re.findall(r"[a-z0-9_]+", (text or "").lower())
    return {w for w in words if len(w) > 2 and w not in STOP}


def _score(query: set[str], target: str) -> float:
    if not query:
        return 0.0
    t = _tokens(target)
    if not t:
        return 0.0
    overlap = len(query & t)
    return overlap / (len(query) ** 0.5)


# ---------------- skills ----------------

def save_skill(name: str, trigger: str, body: str) -> str:
    now = int(time.time())
    with db() as c:
        row = c.execute("SELECT id FROM skills WHERE name=?", (name,)).fetchone()
        if row:
            c.execute(
                "UPDATE skills SET trigger=?, body=?, updated_at=? WHERE id=?",
                (trigger, body, now, row["id"]),
            )
            return f"updated skill '{name}'"
        c.execute(
            "INSERT INTO skills (name, trigger, body, created_at, updated_at) VALUES (?,?,?,?,?)",
            (name, trigger, body, now, now),
        )
    return f"saved new skill '{name}'"


def find_skills(query: str, limit: int = 3, min_score: float = 0.28):
    q = _tokens(query)
    with db() as c:
        rows = c.execute(
            "SELECT id, name, trigger, body, uses, wins FROM skills"
        ).fetchall()
    scored = []
    for r in rows:
        s = max(_score(q, r["trigger"]), _score(q, r["name"]) * 1.2)
        # trust boost: skills that have worked before rank higher
        if r["uses"]:
            s *= 1.0 + min(r["wins"] / max(r["uses"], 1), 1.0) * 0.25
        if s >= min_score:
            scored.append((s, r))
    scored.sort(key=lambda x: -x[0])
    return [(s, dict(r)) for s, r in scored[:limit]]


def mark_skill_used(name: str, worked: bool = True):
    with db() as c:
        c.execute(
            "UPDATE skills SET uses=uses+1, wins=wins+?, updated_at=? WHERE name=?",
            (1 if worked else 0, int(time.time()), name),
        )


def list_skills():
    with db() as c:
        return [dict(r) for r in c.execute(
            "SELECT name, trigger, uses, wins FROM skills ORDER BY uses DESC, updated_at DESC"
        ).fetchall()]


# ---------------- preferences ----------------

def remember(key: str, value: str) -> str:
    now = int(time.time())
    with db() as c:
        c.execute(
            "INSERT INTO preferences (key, value, created_at, updated_at) VALUES (?,?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
            (key.strip().lower()[:60], value.strip()[:600], now, now),
        )
    return f"remembered {key}"


def preferences(limit: int = 40):
    with db() as c:
        return [dict(r) for r in c.execute(
            "SELECT key, value FROM preferences ORDER BY updated_at DESC LIMIT ?", (limit,)
        ).fetchall()]


def forget(key: str) -> str:
    with db() as c:
        c.execute("DELETE FROM preferences WHERE key=?", (key.strip().lower(),))
    return f"forgot {key}"


# ---------------- lessons ----------------

def note_lesson(mistake: str, fix: str) -> str:
    sig = " ".join(sorted(_tokens(mistake)))[:180] or mistake[:180]
    with db() as c:
        row = c.execute("SELECT id, hits FROM lessons WHERE signature=?", (sig,)).fetchone()
        if row:
            c.execute("UPDATE lessons SET hits=hits+1, fix=? WHERE id=?", (fix[:600], row["id"]))
            return "lesson reinforced"
        c.execute(
            "INSERT INTO lessons (signature, mistake, fix, created_at) VALUES (?,?,?,?)",
            (sig, mistake[:600], fix[:600], int(time.time())),
        )
    return "lesson recorded"


def list_lessons(limit: int = 40):
    with db() as c:
        return [dict(r) for r in c.execute(
            "SELECT signature, mistake, fix, hits FROM lessons ORDER BY hits DESC, created_at DESC LIMIT ?",
            (limit,),
        ).fetchall()]


def forget_lesson(signature: str) -> str:
    with db() as c:
        c.execute("DELETE FROM lessons WHERE signature=?", (signature,))
    return "lesson forgotten"


def find_lessons(query: str, limit: int = 3, min_score: float = 0.3):
    q = _tokens(query)
    with db() as c:
        rows = c.execute("SELECT mistake, fix, hits FROM lessons").fetchall()
    scored = [(_score(q, r["mistake"]), dict(r)) for r in rows]
    scored = [(s, r) for s, r in scored if s >= min_score]
    scored.sort(key=lambda x: -x[0])
    return scored[:limit]


# ---------------- the context block injected each turn ----------------

def build_context(task: str) -> str:
    """Assemble learned context for this specific task. Empty string if nothing."""
    parts = []

    prefs = preferences()
    if prefs:
        lines = "\n".join(f"- {p['key']}: {p['value']}" for p in prefs[:20])
        parts.append("WHAT YOU KNOW ABOUT THIS USER:\n" + lines)

    skills = find_skills(task)
    if skills:
        blocks = []
        for _, s in skills:
            blocks.append(f"### Skill: {s['name']}\nWhen: {s['trigger']}\n{s['body']}")
        parts.append(
            "RELEVANT SKILLS YOU LEARNED EARLIER (reuse these, adapt if needed):\n\n"
            + "\n\n".join(blocks)
        )

    lessons = find_lessons(task)
    if lessons:
        lines = "\n".join(f"- Mistake: {l['mistake']}\n  Fix: {l['fix']}" for _, l in lessons)
        parts.append("MISTAKES YOU MADE BEFORE — DO NOT REPEAT:\n" + lines)

    return "\n\n".join(parts)


def stats():
    with db() as c:
        return {
            "skills": c.execute("SELECT COUNT(*) n FROM skills").fetchone()["n"],
            "preferences": c.execute("SELECT COUNT(*) n FROM preferences").fetchone()["n"],
            "lessons": c.execute("SELECT COUNT(*) n FROM lessons").fetchone()["n"],
        }


# ensure tables exist as soon as the module is imported
init()
