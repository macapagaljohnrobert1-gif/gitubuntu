"""Private single-user agent server. Looks like super.myninja.ai, but it's only yours."""
import json
import os
import queue
import threading
from pathlib import Path

from fastapi import Cookie, FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import store
import memory
import repair
from agent import MAX_STEPS, MODEL, MOCK, run_agent
from tools import WORKDIR

BASE = Path(__file__).parent
STATIC = BASE.parent / "static"

app = FastAPI(title="MyNinja", docs_url=None, redoc_url=None, openapi_url=None)
store.init()
memory.init()
store.purge_sessions()

COOKIE = "ninja_session"
SELF_REPAIR = os.getenv("SELF_REPAIR", "1") == "1"


def _startup_selfcheck():
    """Probe the install in the background so boot stays instant.

    If anything is broken and safely fixable, fix it before the first task
    runs. Failures here are logged, never fatal — a server that refuses to
    start because its own health check crashed would be a worse bug than
    the one it was checking for.
    """
    if not SELF_REPAIR:
        print("[self-repair] disabled (SELF_REPAIR=0)", flush=True)
        return
    try:
        report = repair.check_all()
        if not report.healthy:
            report = repair.repair_all(report)
        print(f"[self-repair] {report.summary()}", flush=True)
    except Exception as e:  # noqa: BLE001
        print(f"[self-repair] startup check failed: {type(e).__name__}: {e}", flush=True)


threading.Thread(target=_startup_selfcheck, daemon=True).start()


# ---------- auth guard ----------

def require(token: str | None):
    if not store.valid_session(token):
        raise HTTPException(status_code=401, detail="not authenticated")


class LoginBody(BaseModel):
    password: str


class DiagnoseBody(BaseModel):
    error: str


@app.post("/api/login")
def login(body: LoginBody, response: Response):
    if not store.check_password(body.password):
        raise HTTPException(status_code=401, detail="wrong password")
    token = store.make_session()
    response.set_cookie(
        COOKIE, token, httponly=True, samesite="lax",
        max_age=30 * 86400, path="/",
    )
    return {"ok": True}


@app.post("/api/logout")
def logout(response: Response, ninja_session: str | None = Cookie(default=None)):
    if ninja_session:
        store.drop_session(ninja_session)
    response.delete_cookie(COOKIE, path="/")
    return {"ok": True}


@app.get("/api/me")
def me(ninja_session: str | None = Cookie(default=None)):
    return {"authed": store.valid_session(ninja_session)}


# ---------- meta ----------

@app.get("/api/health")
def health():
    return {"ok": True, "model": "mock" if MOCK else MODEL, "max_steps": MAX_STEPS}


# ---------- self-repair ----------

@app.get("/api/health/deep")
def health_deep(ninja_session: str | None = Cookie(default=None)):
    """Full probe of the install. Read-only, safe to poll."""
    require(ninja_session)
    return repair.check_all().as_dict()


@app.post("/api/repair")
def run_repair(ninja_session: str | None = Cookie(default=None)):
    """Run the safe fixes for anything that failed. Idempotent."""
    require(ninja_session)
    report = repair.repair_all()
    return report.as_dict()


@app.get("/api/repairs")
def repairs(limit: int = 20, ninja_session: str | None = Cookie(default=None)):
    """History of what broke and what fixed it."""
    require(ninja_session)
    return {"repairs": repair.recent_repairs(limit)}


@app.post("/api/diagnose")
def diagnose(body: DiagnoseBody, ninja_session: str | None = Cookie(default=None)):
    """Map an error string to a cause and a fix without applying anything."""
    require(ninja_session)
    return repair.diagnose_error(body.error)


# ---------- conversations ----------

@app.get("/api/conversations")
def conversations(ninja_session: str | None = Cookie(default=None)):
    require(ninja_session)
    return store.list_conversations()


@app.post("/api/conversations")
def new_conversation(ninja_session: str | None = Cookie(default=None)):
    require(ninja_session)
    return {"id": store.create_conversation()}


@app.delete("/api/conversations/{conv_id}")
def del_conversation(conv_id: int, ninja_session: str | None = Cookie(default=None)):
    require(ninja_session)
    store.delete_conversation(conv_id)
    return {"ok": True}


@app.get("/api/conversations/{conv_id}/messages")
def messages(conv_id: int, ninja_session: str | None = Cookie(default=None)):
    require(ninja_session)
    return {"messages": store.get_messages(conv_id), "events": store.get_events(conv_id)}


# ---------- chat (SSE) ----------

class ChatBody(BaseModel):
    conv_id: int
    message: str


@app.post("/api/chat")
def chat(body: ChatBody, ninja_session: str | None = Cookie(default=None)):
    require(ninja_session)

    history = store.get_messages(body.conv_id)
    store.add_message(body.conv_id, "user", body.message)

    convs = {c["id"]: c for c in store.list_conversations()}
    if body.conv_id in convs and convs[body.conv_id]["title"] == "New task":
        store.touch_conversation(body.conv_id, body.message[:80])
    else:
        store.touch_conversation(body.conv_id)

    def stream():
        # Run the agent in a worker thread so that closing the tab does NOT
        # kill the task. Events are persisted as they happen; the SSE stream
        # is just a live view of them.
        q: queue.Queue = queue.Queue()

        def work():
            final = ""
            try:
                for ev in run_agent(body.message, history):
                    if ev["type"] == "done":
                        final = ev.get("text", "")
                    store.add_event(body.conv_id, ev["type"], json.dumps(ev))
                    q.put(ev)
            except Exception as e:
                err = {"type": "error", "text": str(e)}
                store.add_event(body.conv_id, "error", json.dumps(err))
                q.put(err)
                final = f"(error: {e})"
            store.add_message(body.conv_id, "assistant", final or "(no output)")
            store.touch_conversation(body.conv_id)
            q.put(None)  # sentinel

        threading.Thread(target=work, daemon=True).start()

        while True:
            try:
                ev = q.get(timeout=1.0)
            except queue.Empty:
                yield ": keepalive\n\n"
                continue
            if ev is None:
                break
            yield f"data: {json.dumps(ev)}\n\n"

        yield f"data: {json.dumps({'type': 'end'})}\n\n"

    return StreamingResponse(stream(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache",
                                      "X-Accel-Buffering": "no"})


# ---------- consent gate ----------

class ConsentBody(BaseModel):
    conv_id: int
    decision: str          # "approved" | "declined"
    action: str = ""
    consequences: list[str] = []
    chosen: str = ""       # which alternative they picked, if any


@app.post("/api/consent")
def consent_decision(body: ConsentBody, ninja_session: str | None = Cookie(default=None)):
    require(ninja_session)

    if body.decision == "approved":
        msg = "[CONSENT APPROVED] Proceed with: " + (body.action or "the task as described")
        if body.chosen:
            msg += f"\nUse this route instead: {body.chosen}"
        if body.consequences:
            msg += "\nI accept these consequences: " + "; ".join(body.consequences)
    else:
        msg = ("[CONSENT DECLINED] Do not do that. "
               "Propose a different route that avoids it, or tell me what you need from me.")

    store.add_event(body.conv_id, "consent_decision",
                    json.dumps({"type": "consent_decision", "decision": body.decision,
                                "chosen": body.chosen}))
    return {"ok": True, "resume": msg}


# ---------- memory (self-evolution) ----------

@app.get("/api/memory")
def get_memory(ninja_session: str | None = Cookie(default=None)):
    require(ninja_session)
    return {
        "stats": memory.stats(),
        "skills": memory.list_skills(),
        "preferences": memory.preferences(),
        "lessons": memory.list_lessons(),
    }


class PrefBody(BaseModel):
    key: str
    value: str


@app.post("/api/memory/preference")
def set_pref(body: PrefBody, ninja_session: str | None = Cookie(default=None)):
    require(ninja_session)
    return {"ok": True, "msg": memory.remember(body.key, body.value)}


@app.delete("/api/memory/preference/{key}")
def del_pref(key: str, ninja_session: str | None = Cookie(default=None)):
    require(ninja_session)
    return {"ok": True, "msg": memory.forget(key)}


@app.delete("/api/memory/skill/{name}")
def del_skill(name: str, ninja_session: str | None = Cookie(default=None)):
    require(ninja_session)
    import sqlite3
    with memory.db() as c:
        c.execute("DELETE FROM skills WHERE name=?", (name,))
    return {"ok": True}


@app.delete("/api/memory/lesson/{signature}")
def del_lesson(signature: str, ninja_session: str | None = Cookie(default=None)):
    require(ninja_session)
    return {"ok": True, "msg": memory.forget_lesson(signature)}


# ---------- files ----------

def _resolve(rel: str) -> Path:
    p = (WORKDIR / rel).resolve()
    root = WORKDIR.resolve()
    if p != root and root not in p.parents:
        raise HTTPException(status_code=400, detail="path escapes workspace")
    return p


@app.get("/api/files")
def files(path: str = ".", ninja_session: str | None = Cookie(default=None)):
    require(ninja_session)
    p = _resolve(path)
    if not p.exists():
        return {"path": path, "entries": []}
    entries = []
    for item in sorted(p.iterdir(), key=lambda x: (x.is_file(), x.name.lower())):
        st = item.stat()
        entries.append({
            "name": item.name,
            "dir": item.is_dir(),
            "size": st.st_size,
            "mtime": int(st.st_mtime),
            "path": str(item.relative_to(WORKDIR.resolve())),
        })
    return {"path": path, "entries": entries}


@app.get("/api/files/download")
def download(path: str, ninja_session: str | None = Cookie(default=None)):
    require(ninja_session)
    p = _resolve(path)
    if not p.is_file():
        raise HTTPException(status_code=404, detail="not found")
    return FileResponse(p, filename=p.name)


@app.get("/api/files/raw")
def raw(path: str, ninja_session: str | None = Cookie(default=None)):
    require(ninja_session)
    p = _resolve(path)
    if not p.is_file():
        raise HTTPException(status_code=404, detail="not found")
    if p.stat().st_size > 400_000:
        return JSONResponse({"error": "file too large to preview"}, status_code=413)
    try:
        return {"content": p.read_text(encoding="utf-8", errors="replace")}
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=400)


# ---------- static ----------

app.mount("/", StaticFiles(directory=str(STATIC), html=True), name="static")


@app.exception_handler(404)
def spa_fallback(request: Request, exc):
    if request.url.path.startswith("/api/"):
        return JSONResponse({"detail": "not found"}, status_code=404)
    return FileResponse(STATIC / "index.html")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        app,
        host=os.getenv("HOST", "0.0.0.0"),
        port=int(os.getenv("PORT", "8000")),
        log_level="warning",
    )
