"""SQLite store: users (single), sessions, conversations, messages, events."""
import os
import sqlite3
import time
import secrets
import hashlib
import hmac
from contextlib import contextmanager
from pathlib import Path

DB_PATH = Path(os.getenv("NINJA_DB", str(Path(__file__).parent.parent / "data" / "ninja.db")))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY,
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL DEFAULT 'New task',
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conv_id INTEGER NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (conv_id) REFERENCES conversations(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conv_id INTEGER NOT NULL,
    kind TEXT NOT NULL,
    payload TEXT NOT NULL,
    created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conv_id, id);
CREATE INDEX IF NOT EXISTS idx_ev_conv ON events(conv_id, id);
"""


@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init():
    with db() as c:
        c.executescript(SCHEMA)


# ---------- auth ----------

def _hash(password: str, salt: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 200_000).hex()


def check_password(password: str) -> bool:
    """Single user. Password comes from env NINJA_PASSWORD (plain) or
    NINJA_PASSWORD_HASH + NINJA_PASSWORD_SALT."""
    plain = os.getenv("NINJA_PASSWORD")
    if plain:
        return hmac.compare_digest(password, plain)
    h = os.getenv("NINJA_PASSWORD_HASH")
    s = os.getenv("NINJA_PASSWORD_SALT")
    if h and s:
        return hmac.compare_digest(_hash(password, s), h)
    return False


def make_session(days: int = 30) -> str:
    token = secrets.token_urlsafe(32)
    now = int(time.time())
    with db() as c:
        c.execute("INSERT INTO sessions VALUES (?,?,?)", (token, now, now + days * 86400))
    return token


def valid_session(token: str | None) -> bool:
    if not token:
        return False
    with db() as c:
        row = c.execute("SELECT expires_at FROM sessions WHERE token=?", (token,)).fetchone()
    return bool(row and row["expires_at"] > time.time())


def drop_session(token: str):
    with db() as c:
        c.execute("DELETE FROM sessions WHERE token=?", (token,))


def purge_sessions():
    with db() as c:
        c.execute("DELETE FROM sessions WHERE expires_at < ?", (int(time.time()),))


# ---------- conversations ----------

def list_conversations():
    with db() as c:
        rows = c.execute(
            "SELECT id, title, created_at, updated_at FROM conversations "
            "ORDER BY updated_at DESC"
        ).fetchall()
    return [dict(r) for r in rows]


def create_conversation(title: str = "New task") -> int:
    now = int(time.time())
    with db() as c:
        cur = c.execute(
            "INSERT INTO conversations (title, created_at, updated_at) VALUES (?,?,?)",
            (title[:120], now, now),
        )
        return cur.lastrowid


def delete_conversation(conv_id: int):
    with db() as c:
        c.execute("DELETE FROM events WHERE conv_id=?", (conv_id,))
        c.execute("DELETE FROM messages WHERE conv_id=?", (conv_id,))
        c.execute("DELETE FROM conversations WHERE id=?", (conv_id,))


def touch_conversation(conv_id: int, title: str | None = None):
    with db() as c:
        if title:
            c.execute("UPDATE conversations SET updated_at=?, title=? WHERE id=?",
                      (int(time.time()), title[:120], conv_id))
        else:
            c.execute("UPDATE conversations SET updated_at=? WHERE id=?",
                      (int(time.time()), conv_id))


def add_message(conv_id: int, role: str, content: str) -> int:
    with db() as c:
        cur = c.execute(
            "INSERT INTO messages (conv_id, role, content, created_at) VALUES (?,?,?,?)",
            (conv_id, role, content, int(time.time())),
        )
        return cur.lastrowid


def get_messages(conv_id: int, limit: int = 200):
    with db() as c:
        rows = c.execute(
            "SELECT role, content FROM messages WHERE conv_id=? ORDER BY id ASC LIMIT ?",
            (conv_id, limit),
        ).fetchall()
    return [dict(r) for r in rows]


def add_event(conv_id: int, kind: str, payload: str):
    with db() as c:
        c.execute(
            "INSERT INTO events (conv_id, kind, payload, created_at) VALUES (?,?,?,?)",
            (conv_id, kind, payload, int(time.time())),
        )


def get_events(conv_id: int, limit: int = 500):
    with db() as c:
        rows = c.execute(
            "SELECT kind, payload, created_at FROM events WHERE conv_id=? "
            "ORDER BY id ASC LIMIT ?", (conv_id, limit),
        ).fetchall()
    return [dict(r) for r in rows]
