"""Pre-flight planner: pick the best route before spending steps on a worse one.

Two jobs:
  1. Decide whether a task is worth planning (trivial ones are not).
  2. Ask the model for a recommended approach plus alternatives, with the
     tradeoff of each. The agent then executes the recommendation.
"""
import json
import re

# Tasks that are one-shot and do not benefit from a plan.
TRIVIAL = re.compile(
    r"^\s*(hi|hey|hello|thanks|thank you|ok|okay|yes|no|what time|what'?s the date)\b",
    re.I,
)

# Verbs that imply real work.
WORK_VERBS = re.compile(
    r"\b(build|create|make|write|generate|scaffold|implement|refactor|migrate|"
    r"deploy|install|set ?up|configure|debug|fix|test|benchmark|optimi[sz]e|"
    r"analy[sz]e|scrape|crawl|extract|convert|automate|integrate|research|"
    r"design|audit|review|port|upgrade|publish|package|containeri[sz]e)\b",
    re.I,
)

PLAN_PROMPT = """You are the planning stage of an autonomous coding agent. Do not do the task.
Decide the BEST way to execute it, and name better alternatives the operator may not have considered.

Rules:
- Be concrete. Name real tools, real commands, real libraries.
- The recommended approach must be the one with the best ratio of reliability to effort.
- Alternatives must be genuinely different strategies, not variations. Say what each buys and costs.
- If the user's stated approach is a trap (slow, fragile, deprecated), say so in "warning".
- Never refuse. If part of the task is impossible, plan the closest achievable version and say what you cut.

Reply with JSON only, no prose, no markdown fences:
{
  "approach": "one sentence: the recommended route",
  "why": "one sentence: why this beats the obvious route",
  "steps": ["3-6 concrete steps"],
  "alternatives": [
    {"name": "short label", "how": "one sentence", "tradeoff": "what it costs"}
  ],
  "warning": "optional: the trap in the naive approach, or empty string",
  "fastest": "optional: the 5-minute version if they want it now, or empty string"
}"""


def needs_plan(task: str) -> bool:
    """Cheap heuristic: is this worth a planning call?"""
    t = (task or "").strip()
    if len(t) < 12:
        return False
    if TRIVIAL.match(t):
        return False
    return bool(WORK_VERBS.search(t)) or len(t) > 220


def _extract_json(text: str) -> dict | None:
    """Models wrap JSON in fences or prose. Dig it out."""
    if not text:
        return None
    text = text.strip()
    text = re.sub(r"^```(?:json)?|```$", "", text, flags=re.M).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    start = text.find("{")
    if start == -1:
        return None
    depth = 0
    for i in range(start, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(text[start:i + 1])
                except json.JSONDecodeError:
                    return None
    return None


def make_plan(client, model: str, task: str, learned: str = "") -> dict | None:
    """Return a plan dict, or None if the model gave nothing usable."""
    user = f"TASK: {task}"
    if learned:
        user += f"\n\nWHAT WE ALREADY KNOW (respect it):\n{learned[:1500]}"
    try:
        resp = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": PLAN_PROMPT},
                {"role": "user", "content": user},
            ],
            temperature=0.4,
        )
        raw = resp.choices[0].message.content or ""
    except Exception:
        return None

    plan = _extract_json(raw)
    if not isinstance(plan, dict) or not plan.get("approach"):
        return None

    plan.setdefault("steps", [])
    plan.setdefault("alternatives", [])
    plan.setdefault("why", "")
    plan.setdefault("warning", "")
    plan.setdefault("fastest", "")
    plan["steps"] = [str(s) for s in plan["steps"]][:6]
    plan["alternatives"] = [
        a for a in plan["alternatives"] if isinstance(a, dict) and a.get("name")
    ][:3]
    return plan


def format_plan(plan: dict) -> str:
    """Render the plan into the system prompt so the agent follows it."""
    if not plan:
        return ""
    lines = ["--- APPROVED PLAN (follow this unless a tool result proves it wrong) ---"]
    lines.append(f"Route: {plan['approach']}")
    if plan.get("why"):
        lines.append(f"Because: {plan['why']}")
    if plan["steps"]:
        lines.append("Steps:")
        lines.extend(f"  {i}. {s}" for i, s in enumerate(plan["steps"], 1))
    if plan.get("warning"):
        lines.append(f"AVOID: {plan['warning']}")
    if plan.get("fastest"):
        lines.append(f"If time-boxed: {plan['fastest']}")
    lines.append(
        "Execute this route. If a step fails twice, switch to an alternative "
        "rather than repeating it."
    )
    return "\n".join(lines)
