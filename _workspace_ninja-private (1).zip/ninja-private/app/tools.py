"""Tool layer: the agent's hands. Everything runs inside the VM."""
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

WORKDIR = Path(os.getenv("NINJA_WORKDIR", str(Path(__file__).parent.parent / "workspace")))
WORKDIR.mkdir(parents=True, exist_ok=True)

MAX_OUTPUT = 8000


def _clip(text: str) -> str:
    if len(text) <= MAX_OUTPUT:
        return text
    return text[:MAX_OUTPUT] + f"\n...[truncated {len(text) - MAX_OUTPUT} chars]"


def run_shell(command: str, timeout: int = 120) -> str:
    """Execute a shell command inside the VM sandbox."""
    try:
        p = subprocess.run(
            command, shell=True, cwd=str(WORKDIR), capture_output=True,
            text=True, timeout=timeout,
        )
        out = f"exit_code: {p.returncode}\n"
        if p.stdout:
            out += f"stdout:\n{_clip(p.stdout)}\n"
        if p.stderr:
            out += f"stderr:\n{_clip(p.stderr)}\n"
        return out
    except subprocess.TimeoutExpired:
        return f"error: command timed out after {timeout}s"
    except Exception as e:
        return f"error: {e}"


def run_python(code: str, timeout: int = 120) -> str:
    """Run a Python snippet in a temp file and return its output."""
    fd, path = tempfile.mkstemp(suffix=".py", dir=str(WORKDIR))
    try:
        with os.fdopen(fd, "w") as f:
            f.write(code)
        p = subprocess.run(
            [sys.executable, path], cwd=str(WORKDIR),
            capture_output=True, text=True, timeout=timeout,
        )
        out = f"exit_code: {p.returncode}\n"
        if p.stdout:
            out += f"stdout:\n{_clip(p.stdout)}\n"
        if p.stderr:
            out += f"stderr:\n{_clip(p.stderr)}\n"
        return out
    except subprocess.TimeoutExpired:
        return f"error: python timed out after {timeout}s"
    except Exception as e:
        return f"error: {e}"
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def _safe_path(path: str) -> Path:
    p = (WORKDIR / path).resolve()
    if WORKDIR.resolve() not in p.parents and p != WORKDIR.resolve():
        raise ValueError(f"path escapes workspace: {path}")
    return p


def write_file(path: str, content: str) -> str:
    try:
        p = _safe_path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return f"wrote {len(content)} chars to {path}"
    except Exception as e:
        return f"error: {e}"


def read_file(path: str) -> str:
    try:
        return _clip(_safe_path(path).read_text(encoding="utf-8", errors="replace"))
    except Exception as e:
        return f"error: {e}"


def list_files(path: str = ".") -> str:
    try:
        p = _safe_path(path)
        rows = []
        for item in sorted(p.iterdir()):
            kind = "dir " if item.is_dir() else "file"
            size = item.stat().st_size if item.is_file() else 0
            rows.append(f"{kind} {size:>10}  {item.name}")
        return "\n".join(rows) or "(empty)"
    except Exception as e:
        return f"error: {e}"


def browse(url: str, max_chars: int = 4000) -> str:
    """Load a page in real Chromium and return its visible text."""
    try:
        from playwright.sync_api import sync_playwright

        with sync_playwright() as pw:
            try:
                browser = pw.chromium.launch(headless=True)
            except Exception:
                # running as root / inside a container: Chromium's own sandbox
                # refuses to start. Fall back to --no-sandbox.
                browser = pw.chromium.launch(headless=True, args=["--no-sandbox"])
            page = browser.new_page(user_agent=(
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
            ))
            page.goto(url, wait_until="domcontentloaded", timeout=45000)
            page.wait_for_timeout(1500)
            text = page.inner_text("body")
            browser.close()
        text = "\n".join(line.strip() for line in text.splitlines() if line.strip())
        return _clip(text[:max_chars])
    except Exception as e:
        return f"error browsing {url}: {e}"


UA = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
)


def _bing_decode(href: str) -> str:
    """Bing wraps results in /ck/a?...&u=a1<base64>. Unwrap it."""
    import base64
    import urllib.parse

    if "bing.com/ck/a" not in href:
        return href
    try:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(href).query)
        u = q.get("u", [""])[0]
        if u.startswith("a1"):
            u = u[2:]
            u += "=" * (-len(u) % 4)
            return base64.urlsafe_b64decode(u).decode("utf-8", "ignore")
    except Exception:
        pass
    return href


def _search_ddg(query: str, max_results: int) -> list[str]:
    import requests
    from bs4 import BeautifulSoup

    r = requests.post(
        "https://html.duckduckgo.com/html/",
        data={"q": query},
        headers={"User-Agent": UA},
        timeout=25,
    )
    if r.status_code != 200:
        return []
    soup = BeautifulSoup(r.text, "html.parser")
    out = []
    for res in soup.select(".result")[:max_results]:
        a = res.select_one(".result__a")
        if not a:
            continue
        snip = res.select_one(".result__snippet")
        out.append(
            f"- {a.get_text(strip=True)}\n  {a.get('href', '')}\n  "
            f"{(snip.get_text(strip=True) if snip else '')}"
        )
    return out


def _search_bing(query: str, max_results: int) -> list[str]:
    import requests
    from bs4 import BeautifulSoup

    r = requests.get(
        "https://www.bing.com/search",
        params={"q": query},
        headers={"User-Agent": UA},
        timeout=25,
    )
    if r.status_code != 200:
        return []
    soup = BeautifulSoup(r.text, "html.parser")
    out = []
    for li in soup.select("li.b_algo")[:max_results]:
        a = li.select_one("h2 a")
        if not a:
            continue
        snip = li.select_one(".b_caption p") or li.select_one("p")
        out.append(
            f"- {a.get_text(strip=True)}\n  {_bing_decode(a.get('href', ''))}\n  "
            f"{(snip.get_text(strip=True) if snip else '')}"
        )
    return out


def web_search(query: str, max_results: int = 6) -> str:
    """Search the web. Tries DuckDuckGo, then Bing. Returns titles, URLs, snippets."""
    errors = []
    for name, fn in (("duckduckgo", _search_ddg), ("bing", _search_bing)):
        try:
            hits = fn(query, max_results)
            if hits:
                return "\n".join(hits)
            errors.append(f"{name}: no results")
        except Exception as e:
            errors.append(f"{name}: {e}")
    return "no results (" + "; ".join(errors) + ")"


TOOL_SCHEMAS = [
    {"type": "function", "function": {
        "name": "save_skill",
        "description": (
            "Save a reusable procedure you just worked out, so future tasks reuse it. "
            "Use after solving something non-obvious. Be specific and concrete."
        ),
        "parameters": {"type": "object", "properties": {
            "name": {"type": "string", "description": "short slug, e.g. 'flask-crud-app'"},
            "trigger": {"type": "string", "description": "when to use it, in one sentence"},
            "body": {"type": "string", "description": "the steps/commands/code that worked"},
        }, "required": ["name", "trigger", "body"]}}},
    {"type": "function", "function": {
        "name": "remember",
        "description": (
            "Persist a durable fact about the user's preferences (tone, stack, formatting, "
            "conventions). Use whenever the user corrects you or states a preference."
        ),
        "parameters": {"type": "object", "properties": {
            "key": {"type": "string", "description": "e.g. 'preferred_stack'"},
            "value": {"type": "string"},
        }, "required": ["key", "value"]}}},
    {"type": "function", "function": {
        "name": "note_lesson",
        "description": (
            "Record a mistake you made and the fix, so you never repeat it. "
            "Call this immediately after recovering from an error."
        ),
        "parameters": {"type": "object", "properties": {
            "mistake": {"type": "string", "description": "what went wrong"},
            "fix": {"type": "string", "description": "what actually worked"},
        }, "required": ["mistake", "fix"]}}},
    {"type": "function", "function": {
        "name": "request_consent",
        "description": (
            "Stop and ask the operator before doing something irreversible or risky "
            "(deleting data, dropping a table, force-pushing, touching production, "
            "handling credentials, bulk scraping). Returns a brief with consequences and "
            "alternative routes. Use this INSTEAD of refusing or instead of guessing."
        ),
        "parameters": {"type": "object", "properties": {
            "action": {"type": "string", "description": "exactly what you intend to execute"},
            "why": {"type": "string", "description": "why it is needed for the task"},
        }, "required": ["action"]}}},
    {"type": "function", "function": {
        "name": "suggest_alternatives",
        "description": (
            "Ask the planner for better ways to do the current sub-task. Returns 2-3 "
            "genuinely different strategies with their tradeoffs. Use when you are stuck, "
            "when the obvious approach feels slow, or before committing to a big refactor."
        ),
        "parameters": {"type": "object", "properties": {
            "task": {"type": "string", "description": "what you are trying to do right now"},
        }, "required": ["task"]}}},
    {"type": "function", "function": {
        "name": "recall",
        "description": "Look up skills and lessons relevant to a topic.",
        "parameters": {"type": "object", "properties": {
            "query": {"type": "string"},
        }, "required": ["query"]}}},
    {"type": "function", "function": {
        "name": "run_shell",
        "description": "Run a shell command in the sandbox VM. Use for installing packages, git, file ops, running programs.",
        "parameters": {"type": "object", "properties": {
            "command": {"type": "string", "description": "The shell command"},
            "timeout": {"type": "integer", "description": "Seconds, default 120"},
        }, "required": ["command"]}}},
    {"type": "function", "function": {
        "name": "run_python",
        "description": "Execute a Python snippet and return stdout/stderr.",
        "parameters": {"type": "object", "properties": {
            "code": {"type": "string", "description": "Python source"},
            "timeout": {"type": "integer"},
        }, "required": ["code"]}}},
    {"type": "function", "function": {
        "name": "write_file",
        "description": "Write text to a file in the workspace.",
        "parameters": {"type": "object", "properties": {
            "path": {"type": "string"}, "content": {"type": "string"},
        }, "required": ["path", "content"]}}},
    {"type": "function", "function": {
        "name": "read_file",
        "description": "Read a file from the workspace.",
        "parameters": {"type": "object", "properties": {"path": {"type": "string"}},
                       "required": ["path"]}}},
    {"type": "function", "function": {
        "name": "list_files",
        "description": "List files in a workspace directory.",
        "parameters": {"type": "object", "properties": {"path": {"type": "string"}}}}},
    {"type": "function", "function": {
        "name": "browse",
        "description": "Open a URL in a real headless Chromium browser and return page text.",
        "parameters": {"type": "object", "properties": {
            "url": {"type": "string"}, "max_chars": {"type": "integer"},
        }, "required": ["url"]}}},
    {"type": "function", "function": {
        "name": "web_search",
        "description": "Search the web and return titles, URLs and snippets.",
        "parameters": {"type": "object", "properties": {
            "query": {"type": "string"}, "max_results": {"type": "integer"},
        }, "required": ["query"]}}},
]

def recall(query: str) -> str:
    import memory
    out = []
    skills = memory.find_skills(query, limit=5, min_score=0.15)
    if skills:
        out.append("SKILLS:")
        for _, s in skills:
            out.append(f"- {s['name']} (when: {s['trigger']})\n  {s['body'][:500]}")
    lessons = memory.find_lessons(query, limit=5, min_score=0.15)
    if lessons:
        out.append("LESSONS:")
        for _, l in lessons:
            out.append(f"- mistake: {l['mistake']}\n  fix: {l['fix']}")
    return "\n".join(out) or "nothing learned about that yet"


def suggest_alternatives(task: str) -> str:
    """Ask the planner for better routes. Reuses the same planner prompt."""
    import os
    import planner
    from openai import OpenAI

    client = OpenAI(
        base_url=os.getenv("LLM_BASE_URL", "http://localhost:11434/v1"),
        api_key=os.getenv("LLM_API_KEY", "ollama"),
    )
    model = os.getenv("LLM_MODEL", "qwen2.5:7b")
    plan = planner.make_plan(client, model, task)
    if not plan:
        return "planner unavailable — proceed with your current approach"
    out = [f"RECOMMENDED: {plan['approach']}"]
    if plan.get("why"):
        out.append(f"WHY: {plan['why']}")
    if plan.get("warning"):
        out.append(f"AVOID: {plan['warning']}")
    if plan.get("fastest"):
        out.append(f"FASTEST: {plan['fastest']}")
    if plan["alternatives"]:
        out.append("ALTERNATIVES:")
        for a in plan["alternatives"]:
            out.append(f"- {a['name']}: {a.get('how','')} (cost: {a.get('tradeoff','?')})")
    return "\n".join(out)


def request_consent(action: str, why: str = "") -> str:
    """Ask the operator for a go/no-go, with consequences and alternatives."""
    import os
    import consent
    from openai import OpenAI

    client = OpenAI(
        base_url=os.getenv("LLM_BASE_URL", "http://localhost:11434/v1"),
        api_key=os.getenv("LLM_API_KEY", "ollama"),
    )
    model = os.getenv("LLM_MODEL", "qwen2.5:7b")
    brief = consent.assess(client, model, why or action, action)
    out = [f"ACTION: {brief.get('action','')}"]
    if brief.get("concern"):
        out.append(f"CONCERN: {brief['concern']}")
    if brief.get("consequences"):
        out.append("IF IT GOES WRONG:")
        out.extend(f"- {c}" for c in brief["consequences"])
    if brief.get("alternatives"):
        out.append("ALTERNATIVES:")
        for a in brief["alternatives"]:
            out.append(f"- {a['name']}: {a.get('how','')} (cost: {a.get('tradeoff','?')})")
    if brief.get("recommendation"):
        out.append(f"RECOMMENDED: {brief['recommendation']}")
    out.append("AWAITING OPERATOR DECISION — do not proceed until they approve.")
    return "\n".join(out)


REGISTRY = {
    "save_skill": lambda **kw: __import__("memory").save_skill(**kw),
    "remember": lambda **kw: __import__("memory").remember(**kw),
    "note_lesson": lambda **kw: __import__("memory").note_lesson(**kw),
    "recall": recall,
    "suggest_alternatives": suggest_alternatives,
    "request_consent": request_consent,
    "run_shell": run_shell,
    "run_python": run_python,
    "write_file": write_file,
    "read_file": read_file,
    "list_files": list_files,
    "browse": browse,
    "web_search": web_search,
}


def call_tool(name: str, args: dict) -> str:
    fn = REGISTRY.get(name)
    if not fn:
        return f"error: unknown tool '{name}'"
    try:
        return fn(**args)
    except TypeError as e:
        return f"error: bad arguments for {name}: {e}"
    except Exception as e:
        return f"error: {e}"
